import { ChevronLeft, ChevronRight, Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import BannerCarousel from "@/components/BannerCarousel";

interface Proposal {
  id: string;
  title: string;
  budget: string | null;
  resources: string | null;
  status: string;
  full_name: string | null;
  anonymous_until_review: boolean | null;
}

const Proposals = () => {
  const navigate = useNavigate();
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  useEffect(() => {
    fetchProposals();
  }, []);

  const fetchProposals = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) return;

      // Check if user is admin
      const { data: roleData } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();

      const userIsAdmin = !!roleData;
      setIsAdmin(userIsAdmin);

      // Fetch proposals based on role
      let query = supabase
        .from("proposals")
        .select("*");

      // Only filter by user_id if not admin
      if (!userIsAdmin) {
        query = query.eq("user_id", user.id);
      }

      const { data, error } = await query.order("created_at", { ascending: false });

      if (error) throw error;

      setProposals(data || []);
    } catch (error) {
      console.error("Error fetching proposals:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusLabel = (status: string) => {
    const statusMap: Record<string, string> = {
      pending: "Рассмотрение",
      approved: "Одобрено",
      rejected: "Отклонено",
      in_discussion: "Обсуждение",
    };
    return statusMap[status] || status;
  };

  const getStatusColor = (status: string) => {
    const colorMap: Record<string, string> = {
      pending: "text-muted-foreground",
      approved: "text-green-600",
      rejected: "text-red-600",
      in_discussion: "text-blue-600",
    };
    return colorMap[status] || "text-muted-foreground";
  };

  // Filter proposals based on search and status
  const filteredProposals = proposals.filter((proposal) => {
    const matchesSearch = searchQuery === "" || 
      proposal.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      proposal.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      proposal.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || proposal.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <BannerCarousel slides={[
        {
          title: "МАГАЗИН -",
          subtitle: "ОБМЕНЯЙ ПЭКИ НА ПРИЗЫ",
          description: "Получай баллы за активность и обменивай их на подарки",
          buttonText: "КУПИТЬ",
          buttonLink: "/shop"
        },
        {
          title: "ТВОИ ИДЕИ -",
          subtitle: "НАШЕ СОВМЕСТНОЕ БУДУЩЕЕ",
          description: "Помоги компании развиваться вместе с тобой",
          buttonText: "ПРЕДЛОЖИТЬ",
          buttonLink: "/proposals/new"
        }
      ]} />

      {/* My Proposals */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">{isAdmin ? "Все предложения" : "Мои предложения"}</h2>
          <Button 
            className="bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={() => navigate('/proposals/new')}
          >
            <Plus className="w-4 h-4 mr-2" />
            Создать предложение
          </Button>
        </div>

        {/* Filters */}
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Поиск по названию, имени или номеру..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Статус" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Все статусы</SelectItem>
              <SelectItem value="pending">Рассмотрение</SelectItem>
              <SelectItem value="approved">Одобрено</SelectItem>
              <SelectItem value="rejected">Отклонено</SelectItem>
              <SelectItem value="in_discussion">Обсуждение</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border text-sm text-muted-foreground">
                <th className="text-left py-3 px-4 font-medium">Имя</th>
                <th className="text-left py-3 px-4 font-medium">Номер</th>
                <th className="text-left py-3 px-4 font-medium">Название</th>
                <th className="text-left py-3 px-4 font-medium">Бюджет</th>
                <th className="text-left py-3 px-4 font-medium">Ресурсы</th>
                <th className="text-right py-3 px-4 font-medium">Статус</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-muted-foreground">
                    Загрузка...
                  </td>
                </tr>
              ) : filteredProposals.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-muted-foreground">
                    {proposals.length === 0 ? "У вас пока нет предложений" : "Предложения не найдены"}
                  </td>
                </tr>
              ) : (
                filteredProposals.map((proposal) => (
                  <tr 
                    key={proposal.id} 
                    className="border-b border-border hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => navigate(`/proposals/${proposal.id}`)}
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-9 h-9">
                          <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                            {(proposal.anonymous_until_review && proposal.status === "pending") 
                              ? "??" 
                              : (proposal.full_name?.substring(0, 2).toUpperCase() || "??")}
                          </AvatarFallback>
                        </Avatar>
                        <span className="font-medium">
                          {(proposal.anonymous_until_review && proposal.status === "pending") 
                            ? "Аноним" 
                            : (proposal.full_name || "Аноним")}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-primary">#{proposal.id.substring(0, 6)}</span>
                    </td>
                    <td className="py-4 px-4">{proposal.title}</td>
                    <td className="py-4 px-4">{proposal.budget || "-"}</td>
                    <td className="py-4 px-4">
                      <Badge className="bg-primary text-primary-foreground">
                        {proposal.resources || "0"}
                      </Badge>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <span className={`font-medium ${getStatusColor(proposal.status)}`}>
                        {getStatusLabel(proposal.status)}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default Proposals;
