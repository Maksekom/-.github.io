import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import topographicBg from "@/assets/topographic-bg.jpg";

interface BannerSlide {
  title: string;
  subtitle: string;
  description: string;
  buttonText: string;
  buttonLink: string;
}

interface BannerCarouselProps {
  slides?: BannerSlide[];
}

const defaultSlides: BannerSlide[] = [
  {
    title: "ТВОИ ИДЕИ -",
    subtitle: "НАШЕ СОВМЕСТНОЕ БУДУЩЕЕ",
    description: "Помоги компании развиваться вместе с тобой",
    buttonText: "ПРЕДЛОЖИТЬ",
    buttonLink: "/proposals/new"
  },
  {
    title: "МАГАЗИН -",
    subtitle: "ОБМЕНЯЙ ПЭКИ НА ПРИЗЫ",
    description: "Получай баллы за активность и обменивай их на подарки",
    buttonText: "КУПИТЬ",
    buttonLink: "/shop"
  },
  {
    title: "ПРЕДЛОЖЕНИЯ -",
    subtitle: "СМОТРИ СВОИ ИДЕИ",
    description: "Отслеживай статус своих предложений",
    buttonText: "СМОТРЕТЬ",
    buttonLink: "/proposals"
  }
];

const BannerCarousel = ({ slides = defaultSlides }: BannerCarouselProps) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [slides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  const handleNavigate = (link: string) => {
    console.log('Navigating to:', link); // Debug log
    navigate(link);
  };

  return (
    <div className="relative pb-12">
      {/* Deep shadow layer below banner */}
      <div className="absolute inset-x-0 top-2 h-[300px] rounded-xl blur-3xl bg-black/40 translate-y-6 -z-10" />
      
    <Card className="relative overflow-hidden border-0 rounded-xl bg-transparent h-[300px]">
      {/* Background Image */}
      <div 
        className="absolute inset-0 w-full h-full rounded-lg"
        style={{ 
          backgroundImage: `url(${topographicBg})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      />
      
      {/* Content */}
      <div className="relative z-10 h-full flex items-center px-8">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 px-8 flex items-center transition-opacity duration-500 ${
              index === currentSlide ? "opacity-100" : "opacity-0"
            }`}
          >
            <div className="text-white max-w-2xl">
              <div className="text-sm mb-2 opacity-90">
                {new Date().toLocaleDateString("ru-RU", { 
                  day: "numeric", 
                  month: "long", 
                  year: "numeric" 
                })}
              </div>
              <h1 className="text-4xl font-bold mb-1">{slide.title}</h1>
              <h2 className="text-4xl font-bold mb-3">{slide.subtitle}</h2>
              <p className="text-white/90 mb-6 text-lg">{slide.description}</p>
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90 font-medium"
                onClick={(e) => {
                  e.stopPropagation();
                  handleNavigate(slide.buttonLink);
                }}
              >
                {slide.buttonText}
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Arrows */}
      <button 
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors z-20"
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-5 h-5 text-white" />
      </button>
      <button 
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors z-20"
        aria-label="Next slide"
      >
        <ChevronRight className="w-5 h-5 text-white" />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-20">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentSlide 
                ? "bg-white w-8" 
                : "bg-white/50 hover:bg-white/70"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </Card>
    </div>
  );
};

export default BannerCarousel;
