import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Search, Trash2, Users, FileText, Ban, UserX } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface UserProfile {
  id: string;
  email: string | null;
  full_name: string | null;
  phone: string | null;
  created_at: string;
  banned_until: string | null;
  is_banned: boolean;
  role?: string;
}

interface Proposal {
  id: string;
  title: string;
  category: string;
  status: string;
  user_id: string;
  created_at: string;
  full_name: string | null;
  anonymous_until_review: boolean | null;
}

const AdminPanel = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<UserProfile[]>([]);
  const [filteredProposals, setFilteredProposals] = useState<Proposal[]>([]);
  const [loading, setLoading] = useState(true);
  const [userSearchQuery, setUserSearchQuery] = useState("");
  const [proposalSearchQuery, setProposalSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [deleteProposalId, setDeleteProposalId] = useState<string | null>(null);
  const [deleteUserId, setDeleteUserId] = useState<string | null>(null);
  const [banUserId, setBanUserId] = useState<string | null>(null);
  const [banDuration, setBanDuration] = useState<string>("1");
  const { toast } = useToast();

  useEffect(() => {
    checkAdminAccess();
    fetchUsers();
    fetchProposals();
  }, []);

  useEffect(() => {
    filterUsers();
  }, [users, userSearchQuery, roleFilter]);

  useEffect(() => {
    filterProposals();
  }, [proposals, proposalSearchQuery, statusFilter]);

  const checkAdminAccess = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    if (!roles || roles.role !== 'admin') {
      toast({
        title: "Доступ запрещён",
        description: "У вас нет прав администратора",
        variant: "destructive",
      });
    }
  };

  const fetchUsers = async () => {
    try {
      const { data: profiles, error: profilesError } = await supabase
        .from("profiles")
        .select("*")
        .order("created_at", { ascending: false });

      if (profilesError) throw profilesError;

      const { data: roles } = await supabase
        .from("user_roles")
        .select("user_id, role");

      const usersWithRoles = profiles?.map((profile) => {
        const userRole = roles?.find((r) => r.user_id === profile.id);
        return {
          ...profile,
          role: userRole?.role || "user",
        };
      }) || [];

      setUsers(usersWithRoles);
      setFilteredUsers(usersWithRoles);
    } catch (error) {
      console.error("Error fetching users:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить список пользователей",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchProposals = async () => {
    try {
      const { data, error } = await supabase
        .from("proposals")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;

      setProposals(data || []);
      setFilteredProposals(data || []);
    } catch (error) {
      console.error("Error fetching proposals:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить список предложений",
        variant: "destructive",
      });
    }
  };

  const filterUsers = () => {
    let filtered = [...users];

    if (roleFilter !== "all") {
      filtered = filtered.filter(user => user.role === roleFilter);
    }

    if (userSearchQuery.trim()) {
      const query = userSearchQuery.toLowerCase().trim();
      filtered = filtered.filter(user => {
        const email = user.email?.toLowerCase() || "";
        const name = user.full_name?.toLowerCase() || "";
        return email.includes(query) || name.includes(query);
      });
    }

    setFilteredUsers(filtered);
  };

  const filterProposals = () => {
    let filtered = [...proposals];

    if (statusFilter !== "all") {
      filtered = filtered.filter(p => p.status === statusFilter);
    }

    if (proposalSearchQuery.trim()) {
      const query = proposalSearchQuery.toLowerCase().trim();
      filtered = filtered.filter(p => {
        const title = p.title?.toLowerCase() || "";
        const category = p.category?.toLowerCase() || "";
        const name = p.full_name?.toLowerCase() || "";
        return title.includes(query) || category.includes(query) || name.includes(query);
      });
    }

    setFilteredProposals(filtered);
  };

  const handleDeleteProposal = async () => {
    if (!deleteProposalId) return;

    try {
      const { error } = await supabase
        .from("proposals")
        .delete()
        .eq("id", deleteProposalId);

      if (error) throw error;

      toast({
        title: "Успешно",
        description: "Предложение удалено",
      });

      fetchProposals();
      setDeleteProposalId(null);
    } catch (error) {
      console.error("Error deleting proposal:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось удалить предложение",
        variant: "destructive",
      });
    }
  };

  const handleUpdateRole = async (userId: string, newRole: string) => {
    try {
      const roleValue = newRole as 'admin' | 'moderator' | 'user';
      
      const { data: existingRole } = await supabase
        .from("user_roles")
        .select("id")
        .eq("user_id", userId)
        .maybeSingle();

      if (existingRole) {
        const { error } = await supabase
          .from("user_roles")
          .update({ role: roleValue })
          .eq("user_id", userId);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("user_roles")
          .insert([{ user_id: userId, role: roleValue }]);

        if (error) throw error;
      }

      toast({
        title: "Успешно",
        description: "Роль пользователя обновлена",
      });

      fetchUsers();
    } catch (error) {
      console.error("Error updating role:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить роль",
        variant: "destructive",
      });
    }
  };

  const handleBanUser = async () => {
    if (!banUserId) return;

    try {
      let bannedUntil: Date | null = null;
      
      if (banDuration === "permanent") {
        bannedUntil = new Date("2099-12-31");
      } else {
        bannedUntil = new Date();
        bannedUntil.setHours(bannedUntil.getHours() + parseInt(banDuration));
      }

      const { error } = await supabase
        .from("profiles")
        .update({
          banned_until: bannedUntil.toISOString(),
          is_banned: true,
        })
        .eq("id", banUserId);

      if (error) throw error;

      toast({
        title: "Успешно",
        description: banDuration === "permanent" 
          ? "Пользователь заблокирован навсегда" 
          : `Пользователь заблокирован на ${banDuration} ч`,
      });

      fetchUsers();
      setBanUserId(null);
      setBanDuration("1");
    } catch (error) {
      console.error("Error banning user:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось заблокировать пользователя",
        variant: "destructive",
      });
    }
  };

  const handleDeleteUser = async () => {
    if (!deleteUserId) return;

    try {
      const { error } = await supabase
        .from("profiles")
        .delete()
        .eq("id", deleteUserId);

      if (error) throw error;

      toast({
        title: "Успешно",
        description: "Профиль пользователя удалён",
      });

      fetchUsers();
      setDeleteUserId(null);
    } catch (error) {
      console.error("Error deleting user:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось удалить профиль",
        variant: "destructive",
      });
    }
  };

  const getStatusLabel = (status: string) => {
    const statusMap: Record<string, string> = {
      pending: "На рассмотрении",
      approved: "Одобрено",
      rejected: "Отклонено",
      in_discussion: "Обсуждается",
    };
    return statusMap[status] || status;
  };

  const getRoleLabel = (role: string) => {
    const roleMap: Record<string, string> = {
      admin: "Администратор",
      moderator: "Модератор",
      user: "Пользователь",
    };
    return roleMap[role] || role;
  };

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Загрузка...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Панель администратора</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Users Panel */}
        <Card className="flex flex-col h-[600px]">
          <div className="p-6 border-b border-border">
            <div className="flex items-center gap-2 mb-4">
              <Users className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-semibold">Пользователи ({filteredUsers.length})</h2>
            </div>
            
            <div className="space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по email или имени..."
                  value={userSearchQuery}
                  onChange={(e) => setUserSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>

              <Select value={roleFilter} onValueChange={setRoleFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Фильтр по роли" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Все роли</SelectItem>
                  <SelectItem value="admin">Администраторы</SelectItem>
                  <SelectItem value="moderator">Модераторы</SelectItem>
                  <SelectItem value="user">Пользователи</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            <div className="space-y-3">
              {filteredUsers.map((user) => (
                <Card key={user.id} className="p-4 hover:shadow-md transition-shadow">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="font-medium">{user.full_name || "Без имени"}</div>
                        <div className="text-sm text-muted-foreground">{user.email}</div>
                        {user.phone && (
                          <div className="text-sm text-muted-foreground">Тел: {user.phone}</div>
                        )}
                        <div className="text-xs text-muted-foreground mt-1">
                          Регистрация: {new Date(user.created_at).toLocaleDateString("ru-RU")}
                        </div>
                        {user.is_banned && user.banned_until && (
                          <Badge variant="destructive" className="mt-2">
                            Забанен до {new Date(user.banned_until).toLocaleDateString("ru-RU")}
                          </Badge>
                        )}
                      </div>
                      <div className="flex flex-col gap-2">
                        <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                          {getRoleLabel(user.role || 'user')}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 pt-2 border-t border-border">
                      <Select
                        value={user.role || 'user'}
                        onValueChange={(value) => handleUpdateRole(user.id, value)}
                      >
                        <SelectTrigger className="w-[140px] h-8 text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="user">Пользователь</SelectItem>
                          <SelectItem value="moderator">Модератор</SelectItem>
                          <SelectItem value="admin">Администратор</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setBanUserId(user.id)}
                        className="h-8 text-xs"
                      >
                        <Ban className="w-3 h-3 mr-1" />
                        Бан
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setDeleteUserId(user.id)}
                        className="h-8 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        <UserX className="w-3 h-3 mr-1" />
                        Удалить
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </Card>

        {/* Proposals Panel */}
        <Card className="flex flex-col h-[600px]">
          <div className="p-6 border-b border-border">
            <div className="flex items-center gap-2 mb-4">
              <FileText className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-semibold">Предложения ({filteredProposals.length})</h2>
            </div>
            
            <div className="space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Поиск по названию, категории..."
                  value={proposalSearchQuery}
                  onChange={(e) => setProposalSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Фильтр по статусу" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Все статусы</SelectItem>
                  <SelectItem value="pending">На рассмотрении</SelectItem>
                  <SelectItem value="approved">Одобрено</SelectItem>
                  <SelectItem value="rejected">Отклонено</SelectItem>
                  <SelectItem value="in_discussion">Обсуждается</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            <div className="space-y-3">
              {filteredProposals.map((proposal) => (
                <Card key={proposal.id} className="p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{proposal.title}</div>
                      <div className="text-sm text-muted-foreground">{proposal.category}</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        Автор: {(proposal.anonymous_until_review && proposal.status === "pending") 
                          ? "Аноним" 
                          : (proposal.full_name || "Аноним")}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(proposal.created_at).toLocaleDateString("ru-RU")}
                      </div>
                      <Badge variant="outline" className="mt-2">
                        {getStatusLabel(proposal.status)}
                      </Badge>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setDeleteProposalId(proposal.id)}
                      className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Delete Proposal Confirmation Dialog */}
      <AlertDialog open={!!deleteProposalId} onOpenChange={() => setDeleteProposalId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить предложение?</AlertDialogTitle>
            <AlertDialogDescription>
              Это действие нельзя отменить. Предложение будет удалено навсегда.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteProposal} className="bg-destructive hover:bg-destructive/90">
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete User Confirmation Dialog */}
      <AlertDialog open={!!deleteUserId} onOpenChange={() => setDeleteUserId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить профиль пользователя?</AlertDialogTitle>
            <AlertDialogDescription>
              Это действие нельзя отменить. Профиль и все связанные данные будут удалены навсегда.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteUser} className="bg-destructive hover:bg-destructive/90">
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Ban User Dialog */}
      <Dialog open={!!banUserId} onOpenChange={() => setBanUserId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Заблокировать пользователя</DialogTitle>
            <DialogDescription>
              Выберите длительность блокировки
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Select value={banDuration} onValueChange={setBanDuration}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">1 час</SelectItem>
                <SelectItem value="3">3 часа</SelectItem>
                <SelectItem value="6">6 часов</SelectItem>
                <SelectItem value="12">12 часов</SelectItem>
                <SelectItem value="24">1 день</SelectItem>
                <SelectItem value="168">7 дней</SelectItem>
                <SelectItem value="720">30 дней</SelectItem>
                <SelectItem value="permanent">Навсегда</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBanUserId(null)}>
              Отмена
            </Button>
            <Button onClick={handleBanUser} className="bg-destructive hover:bg-destructive/90">
              Заблокировать
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminPanel;
