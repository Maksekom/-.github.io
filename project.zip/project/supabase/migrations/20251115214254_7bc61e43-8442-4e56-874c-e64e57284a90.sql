-- Add policy for admins to delete proposals
CREATE POLICY "Admins can delete proposals"
ON public.proposals
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));