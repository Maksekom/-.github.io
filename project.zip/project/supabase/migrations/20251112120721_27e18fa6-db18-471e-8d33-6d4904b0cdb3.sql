-- Create enum for proposal statuses
CREATE TYPE public.proposal_status AS ENUM (
  'pending',
  'approved',
  'rejected',
  'in_discussion'
);

-- Create enum for user roles
CREATE TYPE public.app_role AS ENUM (
  'admin',
  'moderator',
  'user'
);

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Create proposals table
CREATE TABLE public.proposals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  problem_description TEXT,
  category TEXT NOT NULL,
  proposed_solution TEXT,
  expected_effect TEXT NOT NULL,
  development_level TEXT NOT NULL,
  novelty_score INTEGER CHECK (novelty_score >= 1 AND novelty_score <= 5),
  value_score INTEGER CHECK (value_score >= 1 AND value_score <= 5),
  feasibility_score INTEGER CHECK (feasibility_score >= 1 AND feasibility_score <= 5),
  scalability_score INTEGER CHECK (scalability_score >= 1 AND scalability_score <= 5),
  clarity_score INTEGER CHECK (clarity_score >= 1 AND clarity_score <= 5),
  description TEXT,
  resources TEXT,
  budget TEXT,
  full_name TEXT,
  email TEXT,
  position TEXT,
  department TEXT,
  anonymous_until_review BOOLEAN DEFAULT false,
  status proposal_status NOT NULL DEFAULT 'pending',
  likes_count INTEGER NOT NULL DEFAULT 0,
  comments_count INTEGER NOT NULL DEFAULT 0,
  views_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on proposals
ALTER TABLE public.proposals ENABLE ROW LEVEL SECURITY;

-- RLS Policies for proposals
CREATE POLICY "Users can view all proposals"
ON public.proposals
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Users can create their own proposals"
ON public.proposals
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own proposals"
ON public.proposals
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Admins can update all proposals"
ON public.proposals
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- RLS Policies for user_roles
CREATE POLICY "Users can view their own roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Create trigger for proposals updated_at
CREATE TRIGGER update_proposals_updated_at
BEFORE UPDATE ON public.proposals
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create comments table
CREATE TABLE public.proposal_comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  proposal_id UUID NOT NULL REFERENCES public.proposals(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  comment TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on comments
ALTER TABLE public.proposal_comments ENABLE ROW LEVEL SECURITY;

-- RLS Policies for comments
CREATE POLICY "Users can view all comments"
ON public.proposal_comments
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Users can create comments"
ON public.proposal_comments
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Create trigger for comments updated_at
CREATE TRIGGER update_proposal_comments_updated_at
BEFORE UPDATE ON public.proposal_comments
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();