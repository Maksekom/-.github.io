import { useEffect, useState } from "react";
import { Home, ShoppingBag, FileText, MessageSquare, Settings } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { Link } from "react-router-dom";
import Logo from "./Logo";
import { supabase } from "@/integrations/supabase/client";

const Sidebar = () => {
  const [messageCount, setMessageCount] = useState(0);

  useEffect(() => {
    fetchCounts();

    const msgChannel = supabase
      .channel('messages_count')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'proposal_messages',
        },
        () => fetchCounts()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(msgChannel);
    };
  }, []);

  const fetchCounts = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Fetch unread messages count for user's proposals only
    const { data: userProposals } = await supabase
      .from('proposals')
      .select('id')
      .eq('user_id', user.id);

    if (userProposals && userProposals.length > 0) {
      const proposalIds = userProposals.map(p => p.id);
      
      const { data: messages } = await supabase
        .from('proposal_messages')
        .select('id', { count: 'exact', head: true })
        .in('proposal_id', proposalIds)
        .neq('sender_id', user.id);

      setMessageCount(messages?.length || 0);
    } else {
      setMessageCount(0);
    }
  };

  const menuItems = [
    { icon: Home, label: "Главная", path: "/" },
    { icon: ShoppingBag, label: "Магазин", path: "/shop" },
    { icon: FileText, label: "Предложения", path: "/proposals" },
    { icon: MessageSquare, label: "Сообщения", path: "/messages", badge: messageCount },
    { icon: Settings, label: "Настройки", path: "/settings" },
  ];

  return (
    <aside className="w-64 bg-sidebar/80 backdrop-blur-md flex flex-col h-screen sticky top-0 relative shadow-[2px_0_16px_rgba(0,0,0,0.08)] after:content-[''] after:absolute after:right-0 after:top-16 after:bottom-0 after:w-px after:bg-border/50">
      <Link to="/" className="p-6 block">
        <Logo className="h-10" />
      </Link>
      
      <nav className="flex-1 px-3">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sidebar-foreground hover:bg-cyan-500/20 mb-1 transition-colors"
            activeClassName="bg-sidebar-accent text-sidebar-primary font-medium"
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
            {item.badge !== undefined && item.badge > 0 && (
              <span className="ml-auto bg-muted text-muted-foreground text-xs px-2 py-0.5 rounded-full">
                {item.badge}
              </span>
            )}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
};

export default Sidebar;
