-- Create notifications table
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  type text NOT NULL DEFAULT 'info',
  read boolean NOT NULL DEFAULT false,
  proposal_id uuid REFERENCES public.proposals(id) ON DELETE CASCADE,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Users can view their own notifications
CREATE POLICY "Users can view their own notifications"
ON public.notifications
FOR SELECT
USING (auth.uid() = user_id);

-- Users can update their own notifications (mark as read)
CREATE POLICY "Users can update their own notifications"
ON public.notifications
FOR UPDATE
USING (auth.uid() = user_id);

-- System can insert notifications (via trigger or admin)
CREATE POLICY "Authenticated users can insert notifications"
ON public.notifications
FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

-- Create proposal messages table for chat
CREATE TABLE public.proposal_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  proposal_id uuid NOT NULL REFERENCES public.proposals(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL,
  message text NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.proposal_messages ENABLE ROW LEVEL SECURITY;

-- Users can view messages for their proposals or if they're admin
CREATE POLICY "Users can view messages for their proposals"
ON public.proposal_messages
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.proposals 
    WHERE proposals.id = proposal_messages.proposal_id 
    AND proposals.user_id = auth.uid()
  )
  OR has_role(auth.uid(), 'admin'::app_role)
);

-- Users can insert messages for their proposals or if they're admin
CREATE POLICY "Users can insert messages for their proposals"
ON public.proposal_messages
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.proposals 
    WHERE proposals.id = proposal_messages.proposal_id 
    AND proposals.user_id = auth.uid()
  )
  OR has_role(auth.uid(), 'admin'::app_role)
);

-- Enable realtime for notifications
ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;

-- Enable realtime for messages
ALTER PUBLICATION supabase_realtime ADD TABLE public.proposal_messages;