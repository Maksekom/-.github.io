-- Add RLS policies for updating and deleting proposal messages

-- Users can update their own messages
CREATE POLICY "Users can update their own messages"
ON public.proposal_messages
FOR UPDATE
USING (auth.uid() = sender_id);

-- Users can delete their own messages
CREATE POLICY "Users can delete their own messages"
ON public.proposal_messages
FOR DELETE
USING (auth.uid() = sender_id);

-- Admins can delete any message
CREATE POLICY "Admins can delete any message"
ON public.proposal_messages
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));