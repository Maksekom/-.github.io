import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { title, description, problemDescription, proposedSolution } = await req.json();

    // Combine all text fields for analysis
    const fullText = [
      title,
      description,
      problemDescription,
      proposedSolution
    ].filter(Boolean).join(' ');

    if (!fullText.trim()) {
      return new Response(
        JSON.stringify({ error: 'Нет текста для проверки' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch recent proposals for duplication check
    const { data: existingProposals, error: dbError } = await supabase
      .from('proposals')
      .select('title, description, problem_description, proposed_solution')
      .order('created_at', { ascending: false })
      .limit(50); // Check against last 50 proposals

    if (dbError) {
      console.error('Error fetching proposals:', dbError);
    }

    console.log(`Found ${existingProposals?.length || 0} existing proposals in database`);

    const existingProposalsText = existingProposals?.map(p => 
      `Название: ${p.title}\nОписание: ${p.description || ''}\nПроблема: ${p.problem_description || ''}\nРешение: ${p.proposed_solution || ''}`
    ).join('\n\n---\n\n') || '';

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      console.error('LOVABLE_API_KEY не настроен');
      return new Response(
        JSON.stringify({ error: 'Ошибка конфигурации сервера' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check for profanity and duplication using AI
    const systemPrompt = `Ты - модератор системы предложений. Твоя задача анализировать текст предложений и проверять:
1. Наличие нецензурной лексики, оскорблений или неприемлемого контента
2. Является ли новое предложение ТОЧНЫМ дубликатом существующих предложений

КРИТИЧЕСКИ ВАЖНО - при проверке на дубликаты:
- Дубликатом считай ТОЛЬКО если предложения практически идентичны по содержанию (90%+ совпадение)
- Предложения на ОДНУ И ТУ ЖЕ тему, но с разными подходами, деталями или решениями - НЕ дубликаты
- Даже если тема похожа, но формулировка, детали или предлагаемое решение отличаются - это НЕ дубликат
- Будь СНИСХОДИТЕЛЬНЫМ - лучше пропустить похожее предложение, чем отклонить уникальное

Отвечай СТРОГО в формате JSON:
{
  "hasProfanity": true/false,
  "isDuplicate": true/false,
  "duplicateTitle": "название похожего предложения" (только если isDuplicate=true),
  "reason": "краткое объяснение на русском"
}`;

    const userPrompt = existingProposals && existingProposals.length > 0
      ? `Новое предложение для проверки:\n\n${fullText}\n\n---\n\nСуществующие предложения в системе (всего: ${existingProposals.length}):\n\n${existingProposalsText}`
      : `ВНИМАНИЕ: В системе НЕТ существующих предложений. Это означает что isDuplicate ДОЛЖЕН БЫТЬ false.\n\nПроверь это предложение ТОЛЬКО на наличие нецензурной лексики:\n\n${fullText}`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-pro',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.2,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Превышен лимит запросов, попробуйте позже' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Требуется пополнение баланса Lovable AI' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ error: 'Ошибка при проверке контента' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const data = await response.json();
    const aiResponse = data.choices[0].message.content;
    
    console.log('AI Response:', aiResponse);

    // Parse AI response
    let analysis;
    try {
      // Try to extract JSON from the response
      const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysis = JSON.parse(jsonMatch[0]);
        
        // КРИТИЧЕСКИ ВАЖНО: Если в базе нет предложений, isDuplicate ВСЕГДА должен быть false
        if (!existingProposals || existingProposals.length === 0) {
          analysis.isDuplicate = false;
          if (analysis.duplicateTitle) {
            delete analysis.duplicateTitle;
          }
          console.log('Forced isDuplicate to false - no existing proposals in database');
        }
      } else {
        throw new Error('No JSON found in response');
      }
    } catch (e) {
      console.error('Failed to parse AI response:', e);
      // Fallback: allow the proposal if we can't parse
      analysis = {
        hasProfanity: false,
        isDuplicate: false,
        reason: 'Проверка не удалась, предложение разрешено'
      };
    }

    return new Response(
      JSON.stringify(analysis),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in check-proposal-content:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Неизвестная ошибка' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});