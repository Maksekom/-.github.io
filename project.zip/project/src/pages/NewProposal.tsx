import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Bold, Italic, Link2, Image, List, Underline, X, FileText, Upload } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import topographicBg from "@/assets/topographic-blue-bg.jpg";

const proposalSchema = z.object({
  title: z.string().trim().min(1, "Заполните заголовок идеи").max(200, "Заголовок не должен превышать 200 символов"),
  problemDescription: z.string().max(5000, "Описание проблемы не должно превышать 5000 символов").optional(),
  proposedSolution: z.string().max(5000, "Предлагаемое решение не должно превышать 5000 символов").optional(),
  description: z.string().max(5000, "Описание идеи не должно превышать 5000 символов").optional(),
  resources: z.string().max(500, "Ресурсы не должны превышать 500 символов").optional(),
  budget: z.string().max(500, "Бюджет не должен превышать 500 символов").optional(),
  fullName: z.string().max(100, "Имя не должно превышать 100 символов").optional(),
  email: z.string().email("Введите корректный email").max(255, "Email не должен превышать 255 символов").optional().or(z.literal("")),
  position: z.string().max(100, "Должность не должна превышать 100 символов").optional(),
  department: z.string().max(100, "Отдел не должен превышать 100 символов").optional(),
  noveltyScore: z.number().int().min(1).max(5),
  valueScore: z.number().int().min(1).max(5),
  feasibilityScore: z.number().int().min(1).max(5),
  scalabilityScore: z.number().int().min(1).max(5),
  clarityScore: z.number().int().min(1).max(5),
});

const NewProposal = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [title, setTitle] = useState("");
  const [problemDescription, setProblemDescription] = useState("");
  const [category, setCategory] = useState("документооборот");
  const [proposedSolution, setProposedSolution] = useState("");
  const [expectedEffect, setExpectedEffect] = useState("снижение затрат");
  const [developmentLevel, setDevelopmentLevel] = useState("идея сырая");
  const [novelty, setNovelty] = useState([3]);
  const [value, setValue] = useState([3]);
  const [feasibility, setFeasibility] = useState([3]);
  const [scalability, setScalability] = useState([3]);
  const [clarity, setClarity] = useState([3]);
  const [description, setDescription] = useState("");
  const [resources, setResources] = useState("");
  const [budget, setBudget] = useState("");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [position, setPosition] = useState("");
  const [department, setDepartment] = useState("");
  const [anonymousUntilReview, setAnonymousUntilReview] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<Array<{name: string, url: string, type: string}>>([]);
  const [isUploading, setIsUploading] = useState(false);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Ошибка",
          description: "Необходимо авторизоваться",
          variant: "destructive",
        });
        return;
      }

      const uploadPromises = Array.from(files).map(async (file) => {
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
        
        const { data, error } = await supabase.storage
          .from('proposal-attachments')
          .upload(fileName, file, {
            cacheControl: '3600',
            upsert: false
          });

        if (error) throw error;

        const { data: { publicUrl } } = supabase.storage
          .from('proposal-attachments')
          .getPublicUrl(fileName);

        return {
          name: file.name,
          url: publicUrl,
          type: file.type
        };
      });

      const uploadedFileData = await Promise.all(uploadPromises);
      setUploadedFiles([...uploadedFiles, ...uploadedFileData]);

      toast({
        title: "Успешно!",
        description: `Загружено файлов: ${uploadedFileData.length}`,
      });
    } catch (error) {
      console.error("Error uploading files:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить файлы",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleRemoveFile = async (fileUrl: string) => {
    try {
      const fileName = fileUrl.split('/').pop();
      if (fileName) {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase.storage
            .from('proposal-attachments')
            .remove([`${user.id}/${fileName}`]);
        }
      }
      setUploadedFiles(uploadedFiles.filter(f => f.url !== fileUrl));
    } catch (error) {
      console.error("Error removing file:", error);
    }
  };

  const applyFormatting = (format: 'bold' | 'italic' | 'underline') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = description.substring(start, end);

    if (!selectedText) {
      toast({
        title: "Выберите текст",
        description: "Пожалуйста, выделите текст для форматирования",
      });
      return;
    }

    let formattedText = selectedText;
    switch (format) {
      case 'bold':
        formattedText = `**${selectedText}**`;
        break;
      case 'italic':
        formattedText = `*${selectedText}*`;
        break;
      case 'underline':
        formattedText = `__${selectedText}__`;
        break;
    }

    const newText = description.substring(0, start) + formattedText + description.substring(end);
    setDescription(newText);

    // Restore focus and adjust cursor position
    setTimeout(() => {
      textarea.focus();
      const newPosition = start + formattedText.length;
      textarea.setSelectionRange(newPosition, newPosition);
    }, 0);
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);

    try {
      // Validate all inputs
      const validationResult = proposalSchema.safeParse({
        title,
        problemDescription: problemDescription || undefined,
        proposedSolution: proposedSolution || undefined,
        description: description || undefined,
        resources: resources || undefined,
        budget: budget || undefined,
        fullName: fullName || undefined,
        email: email || undefined,
        position: position || undefined,
        department: department || undefined,
        noveltyScore: novelty[0],
        valueScore: value[0],
        feasibilityScore: feasibility[0],
        scalabilityScore: scalability[0],
        clarityScore: clarity[0],
      });

      if (!validationResult.success) {
        const firstError = validationResult.error.errors[0];
        toast({
          title: "Ошибка валидации",
          description: firstError.message,
          variant: "destructive",
        });
        return;
      }

      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast({
          title: "Ошибка",
          description: "Необходимо авторизоваться",
          variant: "destructive",
        });
        return;
      }

      // Check content using AI before creating proposal
      toast({
        title: "Проверка...",
        description: "Анализируем ваше предложение",
      });

      const { data: checkResult, error: checkError } = await supabase.functions.invoke(
        'check-proposal-content',
        {
          body: {
            title: validationResult.data.title,
            description: validationResult.data.description,
            problemDescription: validationResult.data.problemDescription,
            proposedSolution: validationResult.data.proposedSolution,
          }
        }
      );

      if (checkError) {
        console.error('Content check error:', checkError);
        toast({
          title: "Ошибка",
          description: "Не удалось проверить содержимое предложения",
          variant: "destructive",
        });
        return;
      }

      // If content has issues, automatically reject
      let proposalStatus: "pending" | "rejected" = "pending";
      let rejectionReason = "";

      if (checkResult?.hasProfanity || checkResult?.isDuplicate) {
        proposalStatus = "rejected";
        
        if (checkResult.isDuplicate && checkResult.duplicateTitle) {
          rejectionReason = `Ваше предложение похоже на уже существующее: "${checkResult.duplicateTitle}". ${checkResult.reason}`;
        } else {
          rejectionReason = checkResult.reason || "Предложение не соответствует требованиям";
        }
        
        toast({
          title: "Предложение отклонено",
          description: rejectionReason,
          variant: "destructive",
          duration: 5000,
        });
      }

      const { data: proposalData, error } = await supabase.from("proposals").insert({
        user_id: user.id,
        title: validationResult.data.title,
        problem_description: validationResult.data.problemDescription,
        category,
        proposed_solution: validationResult.data.proposedSolution,
        expected_effect: expectedEffect,
        development_level: developmentLevel,
        novelty_score: validationResult.data.noveltyScore,
        value_score: validationResult.data.valueScore,
        feasibility_score: validationResult.data.feasibilityScore,
        scalability_score: validationResult.data.scalabilityScore,
        clarity_score: validationResult.data.clarityScore,
        description: validationResult.data.description,
        resources: validationResult.data.resources,
        budget: validationResult.data.budget,
        full_name: validationResult.data.fullName,
        email: validationResult.data.email,
        position: validationResult.data.position,
        department: validationResult.data.department,
        anonymous_until_review: anonymousUntilReview,
        status: proposalStatus,
        attachments: uploadedFiles,
      }).select().single();

      if (error) throw error;

      // If rejected, create notification
      if (proposalStatus === "rejected" && proposalData) {
        try {
          await supabase.rpc('create_notification', {
            _user_id: user.id,
            _title: 'Предложение отклонено автоматически',
            _message: rejectionReason,
            _proposal_id: proposalData.id,
            _type: 'rejection'
          });
        } catch (notifError) {
          console.error('Failed to create notification:', notifError);
        }
      }

      if (proposalStatus === "pending") {
        toast({
          title: "Успешно!",
          description: "Ваше предложение отправлено на рассмотрение",
        });
      }

      navigate("/proposals");
    } catch (error) {
      console.error("Error creating proposal:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось создать предложение",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex gap-6 max-w-7xl mx-auto">
      <Card className="p-8 flex-1 bg-white">
        <h1 className="text-2xl font-bold mb-8">Добавление идеи</h1>

        <div className="space-y-6">
          {/* Title */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Заголовок идеи</Label>
            <div className="relative">
              <Input 
                placeholder="Введите заголовок"
                className="pr-20"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                maxLength={100}
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
                {title.length}/100
              </span>
            </div>
          </div>

          {/* Problem Description */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Описание проблемы</Label>
            <div className="relative">
              <Textarea 
                placeholder="Опишите проблему"
                className="min-h-[100px] pr-20"
                value={problemDescription}
                onChange={(e) => setProblemDescription(e.target.value)}
                maxLength={500}
              />
              <span className="absolute right-3 top-3 text-xs text-muted-foreground">
                {problemDescription.length}/500
              </span>
            </div>
          </div>

          {/* Topic */}
          <div>
            <Label className="text-sm font-medium mb-3 block">Тематика</Label>
            <RadioGroup value={category} onValueChange={setCategory}>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="документооборот" id="doc" />
                  <Label htmlFor="doc" className="cursor-pointer">Документооборот</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="ошибка сайта" id="site" />
                  <Label htmlFor="site" className="cursor-pointer">Ошибка сайта</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="бизнес-процессы" id="business" />
                  <Label htmlFor="business" className="cursor-pointer">Бизнес-процессы</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="инфраструктура" id="infra" />
                  <Label htmlFor="infra" className="cursor-pointer">Инфраструктура</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="клиентский сервис" id="client" />
                  <Label htmlFor="client" className="cursor-pointer">Клиентский сервис</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="другое" id="other" />
                  <Label htmlFor="other" className="cursor-pointer">Другое</Label>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* Proposed Solution */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Предложенное решение</Label>
            <div className="relative">
              <Textarea 
                placeholder="Опишите ваше решение"
                className="min-h-[120px] pr-20"
                value={proposedSolution}
                onChange={(e) => setProposedSolution(e.target.value)}
                maxLength={1000}
              />
              <span className="absolute right-3 top-3 text-xs text-muted-foreground">
                {proposedSolution.length}/1000
              </span>
            </div>
          </div>

          {/* Expected Effect */}
          <div>
            <Label className="text-sm font-medium mb-3 block">Ожидаемый эффект</Label>
            <RadioGroup value={expectedEffect} onValueChange={setExpectedEffect}>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="снижение затрат" id="costs" />
                  <Label htmlFor="costs" className="cursor-pointer">Снижение затрат</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="рост удовлетворенности" id="satisfaction" />
                  <Label htmlFor="satisfaction" className="cursor-pointer">Рост удовлетворенности сотрудников</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="увеличение скорости" id="speed" />
                  <Label htmlFor="speed" className="cursor-pointer">Увеличение скорости</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="прочее" id="other-effect" />
                  <Label htmlFor="other-effect" className="cursor-pointer">Прочее</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="повышение качества" id="quality" />
                  <Label htmlFor="quality" className="cursor-pointer">Повышение качества</Label>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* Development Level */}
          <div>
            <Label className="text-sm font-medium mb-3 block">Уровень проработки</Label>
            <RadioGroup value={developmentLevel} onValueChange={setDevelopmentLevel}>
              <div className="grid grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="идея сырая" id="raw" />
                  <Label htmlFor="raw" className="cursor-pointer">"Идея сырая"</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="готова к обсуждению" id="ready" />
                  <Label htmlFor="ready" className="cursor-pointer">Готова к обсуждению</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="решение почти разработано" id="developed" />
                  <Label htmlFor="developed" className="cursor-pointer">Решение почти разработано</Label>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* Self-Assessment Criteria */}
          <div className="space-y-6 pt-4">
            <h3 className="font-semibold">Критерии самооценки</h3>
            
            {/* Новизна */}
            <div>
              <Label className="text-sm mb-3 block">Новизна</Label>
              <div className="relative flex items-center">
                <div className="absolute left-0 right-0 h-[2px] bg-border" style={{ top: '50%', transform: 'translateY(-50%)' }} />
                <div className="relative flex items-center justify-between w-full">
                  {[1, 2, 3, 4, 5].map((score) => (
                    <button
                      key={score}
                      type="button"
                      onClick={() => setNovelty([score])}
                      className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-medium transition-all bg-white ${
                        novelty[0] === score
                          ? 'border-primary text-primary ring-2 ring-primary ring-offset-2'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      {score}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Ценность */}
            <div>
              <Label className="text-sm mb-3 block">Ценность</Label>
              <div className="relative flex items-center">
                <div className="absolute left-0 right-0 h-[2px] bg-border" style={{ top: '50%', transform: 'translateY(-50%)' }} />
                <div className="relative flex items-center justify-between w-full">
                  {[1, 2, 3, 4, 5].map((score) => (
                    <button
                      key={score}
                      type="button"
                      onClick={() => setValue([score])}
                      className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-medium transition-all bg-white ${
                        value[0] === score
                          ? 'border-primary text-primary ring-2 ring-primary ring-offset-2'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      {score}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Реализуемость */}
            <div>
              <Label className="text-sm mb-3 block">Реализуемость</Label>
              <div className="relative flex items-center">
                <div className="absolute left-0 right-0 h-[2px] bg-border" style={{ top: '50%', transform: 'translateY(-50%)' }} />
                <div className="relative flex items-center justify-between w-full">
                  {[1, 2, 3, 4, 5].map((score) => (
                    <button
                      key={score}
                      type="button"
                      onClick={() => setFeasibility([score])}
                      className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-medium transition-all bg-white ${
                        feasibility[0] === score
                          ? 'border-primary text-primary ring-2 ring-primary ring-offset-2'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      {score}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Масштабируемость */}
            <div>
              <Label className="text-sm mb-3 block">Масштабируемость</Label>
              <div className="relative flex items-center">
                <div className="absolute left-0 right-0 h-[2px] bg-border" style={{ top: '50%', transform: 'translateY(-50%)' }} />
                <div className="relative flex items-center justify-between w-full">
                  {[1, 2, 3, 4, 5].map((score) => (
                    <button
                      key={score}
                      type="button"
                      onClick={() => setScalability([score])}
                      className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-medium transition-all bg-white ${
                        scalability[0] === score
                          ? 'border-primary text-primary ring-2 ring-primary ring-offset-2'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      {score}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Ясность описания */}
            <div>
              <Label className="text-sm mb-3 block">Ясность описания</Label>
              <div className="relative flex items-center">
                <div className="absolute left-0 right-0 h-[2px] bg-border" style={{ top: '50%', transform: 'translateY(-50%)' }} />
                <div className="relative flex items-center justify-between w-full">
                  {[1, 2, 3, 4, 5].map((score) => (
                    <button
                      key={score}
                      type="button"
                      onClick={() => setClarity([score])}
                      className={`w-8 h-8 rounded-full border-2 flex items-center justify-center text-xs font-medium transition-all bg-white ${
                        clarity[0] === score
                          ? 'border-primary text-primary ring-2 ring-primary ring-offset-2'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      {score}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Idea Description */}
          <div>
            <Label className="text-sm font-medium mb-2 block">Введите описание идеи</Label>
            <div className="border border-border rounded-lg overflow-hidden">
              <div className="flex items-center gap-1 p-2 border-b border-border bg-muted/30">
                <button 
                  type="button"
                  className="p-1.5 hover:bg-muted rounded transition-colors"
                  onClick={() => applyFormatting('bold')}
                  title="Жирный (выделите текст)"
                >
                  <Bold className="w-4 h-4" />
                </button>
                <button 
                  type="button"
                  className="p-1.5 hover:bg-muted rounded transition-colors"
                  onClick={() => applyFormatting('italic')}
                  title="Курсив (выделите текст)"
                >
                  <Italic className="w-4 h-4" />
                </button>
                <button 
                  type="button"
                  className="p-1.5 hover:bg-muted rounded transition-colors"
                  onClick={() => applyFormatting('underline')}
                  title="Подчеркнутый (выделите текст)"
                >
                  <Underline className="w-4 h-4" />
                </button>
                <div className="h-4 w-px bg-border mx-1" />
                <button 
                  type="button"
                  className="p-1.5 hover:bg-muted rounded transition-colors"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  title="Загрузить файлы"
                >
                  <Upload className="w-4 h-4" />
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="image/*,.pdf,.doc,.docx,.txt"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
              <Textarea 
                ref={textareaRef}
                placeholder="Введите текст..."
                className="min-h-[150px] border-0 focus-visible:ring-0"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
              {uploadedFiles.length > 0 && (
                <div className="p-3 border-t border-border bg-muted/10">
                  <p className="text-xs text-muted-foreground mb-2">Прикрепленные файлы:</p>
                  <div className="space-y-2">
                    {uploadedFiles.map((file, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm bg-background rounded p-2">
                        {file.type.startsWith('image/') ? (
                          <Image className="w-4 h-4 text-muted-foreground" />
                        ) : (
                          <FileText className="w-4 h-4 text-muted-foreground" />
                        )}
                        <span className="flex-1 truncate">{file.name}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveFile(file.url)}
                          className="p-1 hover:bg-destructive/10 rounded transition-colors"
                          title="Удалить файл"
                        >
                          <X className="w-3 h-3 text-destructive" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Additional Fields */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium mb-2 block">Ресурсы</Label>
              <Input placeholder="Введите количество" value={resources} onChange={(e) => setResources(e.target.value)} />
            </div>
            <div>
              <Label className="text-sm font-medium mb-2 block">Бюджет</Label>
              <Input placeholder="Введите сумму" value={budget} onChange={(e) => setBudget(e.target.value)} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium mb-2 block">ФИО</Label>
              <Input placeholder="Ваше имя" value={fullName} onChange={(e) => setFullName(e.target.value)} />
            </div>
            <div>
              <Label className="text-sm font-medium mb-2 block">E-mail</Label>
              <Input type="email" placeholder="example@mail.ru" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium mb-2 block">Должность</Label>
              <Input placeholder="Ваша должность" value={position} onChange={(e) => setPosition(e.target.value)} />
            </div>
            <div>
              <Label className="text-sm font-medium mb-2 block">Отдел</Label>
              <Input placeholder="Название отдела" value={department} onChange={(e) => setDepartment(e.target.value)} />
            </div>
          </div>

          {/* Anonymous */}
          <div>
            <Label className="text-sm font-medium mb-3 block">Анонимно до оценки</Label>
            <RadioGroup value={anonymousUntilReview ? "yes" : "no"} onValueChange={(val) => setAnonymousUntilReview(val === "yes")}>
              <div className="flex gap-6">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="yes" id="anon-yes" />
                  <Label htmlFor="anon-yes" className="cursor-pointer">ВКЛ</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="no" id="anon-no" />
                  <Label htmlFor="anon-no" className="cursor-pointer">ВЫКЛ</Label>
                </div>
              </div>
            </RadioGroup>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button 
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={handleSubmit}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Отправка..." : "Отправить"}
            </Button>
            <Button variant="outline" className="border-primary text-primary hover:bg-primary/5">
              Поделиться
            </Button>
            <Button variant="outline" className="border-primary text-primary hover:bg-primary/5">
              Пригласить соавтора
            </Button>
          </div>
        </div>
      </Card>

      {/* Right Panel */}
      <div 
        className="w-96 rounded-lg flex-shrink-0 p-12 pt-16 text-white bg-cover bg-center"
        style={{ backgroundImage: `url(${topographicBg})` }}
      >
        <h2 className="text-5xl font-bold mb-6 leading-tight">Твоя идея</h2>
        <p className="text-lg leading-relaxed opacity-90">
          Расскажи какую<br />
          перемену ты хочешь<br />
          сделать
        </p>
      </div>
    </div>
  );
};

export default NewProposal;
