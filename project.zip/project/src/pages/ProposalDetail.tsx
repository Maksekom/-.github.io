import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import BannerCarousel from "@/components/BannerCarousel";
import { FileText, Image as ImageIcon } from "lucide-react";

interface Proposal {
  id: string;
  title: string;
  problem_description: string | null;
  proposed_solution: string | null;
  description: string | null;
  category: string;
  expected_effect: string;
  development_level: string;
  full_name: string | null;
  email: string | null;
  position: string | null;
  department: string | null;
  resources: string | null;
  budget: string | null;
  status: string;
  created_at: string;
  anonymous_until_review: boolean | null;
  attachments: Array<{name: string, url: string, type: string}> | null;
}

const ProposalDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [proposal, setProposal] = useState<Proposal | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (id) {
      fetchProposal();
      checkAdminRole();
    }
  }, [id]);

  const checkAdminRole = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) return;

      const { data: roleData } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();

      setIsAdmin(!!roleData);
    } catch (error) {
      console.error("Error checking admin role:", error);
    }
  };

  const fetchProposal = async () => {
    try {
      const { data, error } = await supabase
        .from("proposals")
        .select("*")
        .eq("id", id)
        .single();

      if (error) throw error;

      setProposal({
        ...data,
        attachments: (data.attachments as any) || []
      });
    } catch (error) {
      console.error("Error fetching proposal:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить предложение",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusLabel = (status: string) => {
    const statusMap: Record<string, string> = {
      pending: "На рассмотрении",
      approved: "Одобрено",
      rejected: "Отклонено",
      in_discussion: "На обсуждении",
    };
    return statusMap[status] || status;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <p className="text-muted-foreground">Загрузка...</p>
      </div>
    );
  }

  if (!proposal) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <p className="text-muted-foreground">Предложение не найдено</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Banner Carousel */}
      <BannerCarousel slides={[
        {
          title: "КУПИ МЕРЧ ТОЛЬКО СЕГОДНЯ",
          subtitle: "СО СКИДКОЙ В 20%",
          description: "Не упусти момент - все зависит от твоих идей",
          buttonText: "КУПИТЬ",
          buttonLink: "/shop"
        },
        {
          title: "ТВОИ ИДЕИ -",
          subtitle: "НАШЕ СОВМЕСТНОЕ БУДУЩЕЕ",
          description: "Помоги компании развиваться вместе с тобой",
          buttonText: "ПРЕДЛОЖИТЬ",
          buttonLink: "/proposals/new"
        },
        {
          title: "МОИ ПРЕДЛОЖЕНИЯ -",
          subtitle: "ОТСЛЕЖИВАЙ СТАТУС",
          description: "Смотри, что происходит с твоими идеями",
          buttonText: "СМОТРЕТЬ",
          buttonLink: "/proposals"
        }
      ]} />

      {/* Proposal Details */}
      <Card className="p-8">
        <div className="mb-6">
          <h2 className="text-sm text-muted-foreground mb-1">Предложение от:</h2>
          <p className="text-lg font-semibold">
            {(proposal.anonymous_until_review && proposal.status === "pending") 
              ? "Аноним" 
              : (proposal.full_name || "Аноним")}
          </p>
          <p className="text-sm text-muted-foreground">
            {(proposal.anonymous_until_review && proposal.status === "pending") 
              ? "-" 
              : (proposal.department || "-")}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-8 mb-8">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Номер предложения:</p>
            <p className="text-lg font-semibold">#{proposal.id.substring(0, 8)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">
              Дата подачи: {new Date(proposal.created_at).toLocaleDateString("ru-RU")}
            </p>
            <p className="text-sm text-muted-foreground mb-3">
              Статус: {getStatusLabel(proposal.status)}
            </p>
            {isAdmin && (
              <Button 
                onClick={() => navigate(`/admin/proposals/${id}`)}
                variant="default"
                size="sm"
                className="mt-2"
              >
                Перейти к рассмотрению
              </Button>
            )}
          </div>
        </div>

        {/* Stages Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-4 px-4 font-medium text-muted-foreground">Нумерация</th>
                <th className="text-left py-4 px-4 font-medium text-muted-foreground">Этап</th>
                <th className="text-center py-4 px-4 font-medium text-muted-foreground">Бюджет</th>
                <th className="text-center py-4 px-4 font-medium text-muted-foreground">Ресурсы</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-border">
                <td className="py-4 px-4">1</td>
                <td className="py-4 px-4">
                  <div>
                    <p className="font-medium">Название</p>
                    <p className="text-sm text-muted-foreground">{proposal.title}</p>
                  </div>
                </td>
                <td className="py-4 px-4 text-center">-</td>
                <td className="py-4 px-4 text-center">-</td>
              </tr>
              <tr className="border-b border-border">
                <td className="py-4 px-4">2</td>
                 <td className="py-4 px-4">
                   <div>
                     <p className="font-medium">Описание</p>
                     <p className="text-sm text-muted-foreground whitespace-pre-wrap">{proposal.description || "Не указано"}</p>
                     {proposal.attachments && proposal.attachments.length > 0 && (
                       <div className="mt-3 space-y-2">
                         <p className="text-xs text-muted-foreground">Прикрепленные файлы:</p>
                         {proposal.attachments.map((file, idx) => (
                           <a
                             key={idx}
                             href={file.url}
                             target="_blank"
                             rel="noopener noreferrer"
                             className="flex items-center gap-2 text-sm text-primary hover:underline"
                           >
                             {file.type.startsWith('image/') ? (
                               <ImageIcon className="w-4 h-4" />
                             ) : (
                               <FileText className="w-4 h-4" />
                             )}
                             {file.name}
                           </a>
                         ))}
                       </div>
                     )}
                   </div>
                 </td>
                <td className="py-4 px-4 text-center">{proposal.budget || "-"}</td>
                <td className="py-4 px-4 text-center">{proposal.resources || "-"}</td>
              </tr>
              <tr className="border-b border-border">
                <td className="py-4 px-4">3</td>
                <td className="py-4 px-4">
                  <div>
                    <p className="font-medium">Тематика</p>
                    <p className="text-sm text-muted-foreground">{proposal.category}</p>
                  </div>
                </td>
                <td className="py-4 px-4 text-center">-</td>
                <td className="py-4 px-4 text-center">-</td>
              </tr>
              <tr className="border-b border-border">
                <td className="py-4 px-4">4</td>
                <td className="py-4 px-4">
                  <div>
                    <p className="font-medium">Ожидаемый эффект</p>
                    <p className="text-sm text-muted-foreground">{proposal.expected_effect}</p>
                  </div>
                </td>
                <td className="py-4 px-4 text-center">-</td>
                <td className="py-4 px-4 text-center">-</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="mt-8 flex justify-between items-center">
          <div className="text-xl font-bold">
            Общее = {proposal.budget || "Не указано"}
          </div>
        </div>
      </Card>
    </div>
  );
};

export default ProposalDetail;
