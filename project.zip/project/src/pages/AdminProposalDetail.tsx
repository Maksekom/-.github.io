import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, MessageCircle, Eye, FileText, Image as ImageIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Proposal {
  id: string;
  title: string;
  problem_description: string | null;
  proposed_solution: string | null;
  description: string | null;
  category: string;
  expected_effect: string;
  development_level: string;
  full_name: string | null;
  email: string | null;
  position: string | null;
  department: string | null;
  resources: string | null;
  budget: string | null;
  status: string;
  likes_count: number;
  comments_count: number;
  views_count: number;
  created_at: string;
  anonymous_until_review: boolean | null;
  attachments: Array<{name: string, url: string, type: string}> | null;
}

const AdminProposalDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [proposal, setProposal] = useState<Proposal | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchProposal();
    }
  }, [id]);

  const fetchProposal = async () => {
    try {
      const { data, error } = await supabase
        .from("proposals")
        .select("*")
        .eq("id", id)
        .single();

      if (error) throw error;

      setProposal({
        ...data,
        attachments: (data.attachments as any) || []
      });
      
      // Increment views
      await supabase
        .from("proposals")
        .update({ views_count: data.views_count + 1 })
        .eq("id", id);
    } catch (error) {
      console.error("Error fetching proposal:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось загрузить предложение",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (newStatus: "pending" | "approved" | "rejected" | "in_discussion") => {
    if (!proposal) return;

    try {
      const { error } = await supabase
        .from("proposals")
        .update({ status: newStatus })
        .eq("id", proposal.id);

      if (error) throw error;

      // Create notification for proposal author
      const statusMessages: Record<string, string> = {
        approved: "Одобрено",
        in_discussion: "На обсуждении",
        rejected: "Отклонено",
        pending: "На рассмотрении"
      };

      const { data: proposalData } = await supabase
        .from("proposals")
        .select("user_id, title")
        .eq("id", proposal.id)
        .single();

      if (proposalData) {
        // Use secure RPC function - only admins can create notifications
        await supabase.rpc('create_notification', {
          _user_id: proposalData.user_id,
          _title: `Ваша заявка "${statusMessages[newStatus]}"`,
          _message: `Статус вашего предложения "${proposalData.title}" изменен на: ${statusMessages[newStatus]}`,
          _proposal_id: proposal.id,
        });
      }

      toast({
        title: "Успешно!",
        description: `Статус изменен на "${getStatusLabel(newStatus)}"`,
      });

      setProposal({ ...proposal, status: newStatus });

      // Redirect to messages if status is approved or in_discussion
      if (newStatus === "approved" || newStatus === "in_discussion") {
        // Create initial message if no messages exist
        const { data: existingMessages } = await supabase
          .from('proposal_messages')
          .select('id')
          .eq('proposal_id', proposal.id)
          .limit(1);

        if (!existingMessages || existingMessages.length === 0) {
          // Create first message from admin
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            await supabase
              .from('proposal_messages')
              .insert({
                proposal_id: proposal.id,
                sender_id: user.id,
                message: newStatus === "approved" 
                  ? "Поздравляем! Ваша заявка одобрена. Давайте обсудим детали реализации."
                  : "Ваша заявка передана на обсуждение. Готовы ответить на ваши вопросы.",
              });
          }
        }

        navigate(`/messages/${proposal.id}`);
      }
    } catch (error) {
      console.error("Error updating status:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось обновить статус",
        variant: "destructive",
      });
    }
  };

  const getStatusLabel = (status: string) => {
    const statusMap: Record<string, string> = {
      pending: "на рассмотрении",
      approved: "одобрено",
      rejected: "отклонено",
      in_discussion: "на обсуждении",
    };
    return statusMap[status] || status;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <p className="text-muted-foreground">Загрузка...</p>
      </div>
    );
  }

  if (!proposal) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <p className="text-muted-foreground">Предложение не найдено</p>
      </div>
    );
  }

  const displayName = (proposal.anonymous_until_review && proposal.status === "pending") 
    ? "Аноним" 
    : (proposal.full_name || "Аноним");
  
  const displayPosition = (proposal.anonymous_until_review && proposal.status === "pending") 
    ? "-" 
    : (proposal.position || "-");
  
  const displayDepartment = (proposal.anonymous_until_review && proposal.status === "pending") 
    ? "-" 
    : (proposal.department || "-");
  
  const displayEmail = (proposal.anonymous_until_review && proposal.status === "pending") 
    ? "-" 
    : (proposal.email || "-");

  const statuses = [
    { label: proposal.category, active: true },
    { label: proposal.expected_effect, active: false },
    { label: proposal.development_level, active: true },
    { label: displayName, active: false },
    { label: displayPosition, active: false },
    { label: displayDepartment, active: false },
    { label: displayEmail, active: false },
    { label: proposal.resources ? `Требует ресурсов: ${proposal.resources}` : "Не требует ресурсов", active: false },
    { label: proposal.budget || "Бюджет не указан", active: false },
    { label: new Date(proposal.created_at).toLocaleDateString("ru-RU"), active: false },
  ];

  return (
    <div className="grid grid-cols-3 gap-6">
      {/* Main Content */}
      <div className="col-span-2">
        <Card className="p-8">
          <div className="flex items-start gap-6 mb-8">
            <Avatar className="w-20 h-20">
              <AvatarImage src="" />
              <AvatarFallback className="bg-muted text-2xl">
                ГФ
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-2xl font-bold">
                  {(proposal.anonymous_until_review && proposal.status === "pending") 
                    ? "Аноним" 
                    : (proposal.full_name || "Аноним")}
                </h1>
                <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
                  идея сотрудника
                </Badge>
                <Badge className="bg-pink-500 text-white hover:bg-pink-500">
                  {proposal.development_level}
                </Badge>
              </div>
              <p className="text-xl mb-4">{proposal.title}</p>
            </div>
          </div>

          <div className="space-y-6 mb-8">
            <div>
              <h2 className="font-semibold mb-2">Идея:</h2>
              <Card className="p-4 bg-muted/30">
                <p className="text-sm mb-3">
                  <strong>Заголовок идеи:</strong><br />
                  {proposal.title}
                </p>
                <p className="text-sm mb-3">
                  <strong>Описание проблемы:</strong><br />
                  {proposal.problem_description || "Не указано"}
                </p>
                <p className="text-sm mb-3">
                  <strong>Предложенное решение:</strong><br />
                  {proposal.proposed_solution || "Не указано"}
                </p>
                <p className="text-sm mb-3">
                  <strong>Описание идеи:</strong><br />
                  <span className="whitespace-pre-wrap">{proposal.description || "Не указано"}</span>
                </p>
                {proposal.attachments && proposal.attachments.length > 0 && (
                  <div className="text-sm mb-3">
                    <strong>Прикрепленные файлы:</strong>
                    <div className="mt-2 space-y-2">
                      {proposal.attachments.map((file, idx) => (
                        <a
                          key={idx}
                          href={file.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-primary hover:underline"
                        >
                          {file.type.startsWith('image/') ? (
                            <ImageIcon className="w-4 h-4" />
                          ) : (
                            <FileText className="w-4 h-4" />
                          )}
                          {file.name}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
                <p className="text-sm">
                  <strong>Вложения:</strong> {proposal.attachments && proposal.attachments.length > 0 ? `${proposal.attachments.length} файл(ов)` : 'Нет'}
                </p>
              </Card>
            </div>

            <div className="flex items-center gap-6 text-muted-foreground">
              <button className="flex items-center gap-2 hover:text-foreground transition-colors">
                <Heart className="w-5 h-5" />
                <span className="text-sm">{proposal.likes_count}</span>
              </button>
              <button className="flex items-center gap-2 hover:text-foreground transition-colors">
                <MessageCircle className="w-5 h-5" />
                <span className="text-sm">{proposal.comments_count}</span>
              </button>
              <button className="flex items-center gap-2 hover:text-foreground transition-colors">
                <Eye className="w-5 h-5" />
                <span className="text-sm">{proposal.views_count}</span>
              </button>
            </div>
          </div>

          <div className="flex gap-3">
            <Button 
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              onClick={() => updateStatus("approved")}
              disabled={proposal.status === "approved"}
            >
              Одобрить
            </Button>
            <Button 
              variant="outline" 
              className="border-primary text-primary hover:bg-primary/5"
              onClick={() => updateStatus("in_discussion")}
              disabled={proposal.status === "in_discussion"}
            >
              Обсудить
            </Button>
            <Button 
              variant="outline"
              className="border-destructive text-destructive hover:bg-destructive/5"
              onClick={() => updateStatus("rejected")}
              disabled={proposal.status === "rejected"}
            >
              Отказ
            </Button>
          </div>
        </Card>
      </div>

      {/* Sidebar with Statuses */}
      <div>
        <Card className="p-6 bg-gradient-to-b from-primary to-primary/90 text-white">
          <h2 className="font-semibold mb-4">Статусы:</h2>
          <div className="space-y-2">
            {statuses.map((status, index) => (
              <div
                key={index}
                className={`px-4 py-2.5 rounded-lg border ${
                  status.active 
                    ? 'bg-white text-foreground border-white' 
                    : 'bg-transparent border-white/30 text-white'
                }`}
              >
                {status.label}
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default AdminProposalDetail;
