import { useEffect, useState, useRef, useCallback, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { ArrowLeft, Send, Pencil, Trash2, X, Paperclip, FileText, Image as ImageIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { z } from 'zod';

const messageSchema = z.object({
  message: z.string()
    .trim()
    .min(1, 'Сообщение не может быть пустым')
    .max(2000, 'Сообщение не может быть длиннее 2000 символов')
});

interface Message {
  id: string;
  sender_id: string;
  message: string;
  created_at: string;
  edited_at?: string | null;
  file_url?: string | null;
  file_name?: string | null;
  file_type?: string | null;
}

interface MessageWithProfile extends Message {
  sender_profile?: {
    full_name: string | null;
    avatar_url: string | null;
  };
}

interface Proposal {
  id: string;
  title: string;
  user_id: string;
}

interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
}

interface ProposalChatProps {
  embedded?: boolean;
}

export default function ProposalChat({ embedded = false }: ProposalChatProps) {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [messages, setMessages] = useState<MessageWithProfile[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [currentUserId, setCurrentUserId] = useState<string>('');
  const [proposal, setProposal] = useState<Proposal | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [otherUserName, setOtherUserName] = useState<string>('');
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [deletingMessageId, setDeletingMessageId] = useState<string | null>(null);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    checkAdminAndFetchData();
    
    // Subscribe to message changes
    const messagesChannel = supabase
      .channel('proposal_messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'proposal_messages',
          filter: `proposal_id=eq.${id}`,
        },
        async (payload) => {
          const newMsg = payload.new as Message;
          // Fetch profile for the new message sender
          const { data: profile } = await supabase
            .from('profiles')
            .select('id, full_name, avatar_url')
            .eq('id', newMsg.sender_id)
            .single();

          setMessages(prev => [...prev, { ...newMsg, sender_profile: profile || undefined }]);
          scrollToBottom();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'proposal_messages',
          filter: `proposal_id=eq.${id}`,
        },
        (payload) => {
          setMessages(prev => 
            prev.map(msg => msg.id === payload.new.id ? { ...payload.new as Message, sender_profile: msg.sender_profile } : msg)
          );
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'proposal_messages',
          filter: `proposal_id=eq.${id}`,
        },
        (payload) => {
          setMessages(prev => prev.filter(msg => msg.id !== payload.old.id));
        }
      )
      .subscribe();

    // Subscribe to presence for online status
    const presenceChannel = supabase.channel(`proposal_${id}_presence`, {
      config: {
        presence: {
          key: currentUserId,
        },
      },
    });

    presenceChannel
      .on('presence', { event: 'sync' }, () => {
        const state = presenceChannel.presenceState();
        const users = new Set<string>();
        Object.values(state).forEach((presences: any) => {
          presences.forEach((presence: any) => {
            if (presence.user_id) {
              users.add(presence.user_id);
            }
          });
        });
        setOnlineUsers(users);
      })
      .on('presence', { event: 'join' }, ({ key, newPresences }) => {
        console.log('User joined:', key, newPresences);
      })
      .on('presence', { event: 'leave' }, ({ key, leftPresences }) => {
        console.log('User left:', key, leftPresences);
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED' && currentUserId) {
          await presenceChannel.track({
            user_id: currentUserId,
            online_at: new Date().toISOString(),
          });
        }
      });

    return () => {
      supabase.removeChannel(messagesChannel);
      supabase.removeChannel(presenceChannel);
    };
  }, [id, currentUserId]);

  const checkAdminAndFetchData = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate('/login');
      return;
    }

    setCurrentUserId(user.id);

    // Client-side check for UX only - actual authorization enforced by RLS
    const { data: roles } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    const adminStatus = roles?.role === 'admin';
    setIsAdmin(adminStatus);

    // Fetch proposal
    const { data: proposalData } = await supabase
      .from('proposals')
      .select('id, title, user_id')
      .eq('id', id)
      .single();

    if (proposalData) {
      setProposal(proposalData);
      
      // Check access
      if (!adminStatus && proposalData.user_id !== user.id) {
        toast({
          title: 'Ошибка доступа',
          description: 'У вас нет доступа к этому чату',
          variant: 'destructive',
        });
        navigate('/proposals');
        return;
      }

      // Fetch other user's profile
      const otherUserId = adminStatus ? proposalData.user_id : null;
      
      if (otherUserId) {
        // Admin viewing user's proposal - show user's name
        const { data: profile } = await supabase
          .from('profiles')
          .select('full_name, email')
          .eq('id', otherUserId)
          .single();
        
        if (profile) {
          setOtherUserName(profile.full_name || profile.email || 'Пользователь');
        }
      } else {
        // User viewing their own proposal - show Admin
        setOtherUserName('Администратор');
      }
    }

    // Fetch messages
    fetchMessages();
  };

  const fetchMessages = useCallback(async () => {
    const { data: messagesData } = await supabase
      .from('proposal_messages')
      .select('*')
      .eq('proposal_id', id)
      .order('created_at', { ascending: true });

    if (messagesData) {
      // Fetch profiles for all unique sender IDs
      const senderIds = [...new Set(messagesData.map(m => m.sender_id))];
      const { data: profiles } = await supabase
        .from('profiles')
        .select('id, full_name, avatar_url')
        .in('id', senderIds);

      // Map profiles to messages with stable references
      const messagesWithProfiles = messagesData.map(msg => ({
        ...msg,
        sender_profile: profiles?.find(p => p.id === msg.sender_id)
      }));

      setMessages(messagesWithProfiles);
      setTimeout(scrollToBottom, 100);
    }
  }, [id]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: 'Ошибка',
        description: 'Размер файла не должен превышать 10 МБ',
        variant: 'destructive',
      });
      return;
    }

    // Validate file type
    const allowedTypes = [
      'image/jpeg', 'image/png', 'image/gif', 'image/webp',
      'application/pdf', 'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/plain'
    ];

    if (!allowedTypes.includes(file.type)) {
      toast({
        title: 'Ошибка',
        description: 'Неподдерживаемый тип файла',
        variant: 'destructive',
      });
      return;
    }

    setSelectedFile(file);
  };

  const uploadFile = async (file: File): Promise<string | null> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${currentUserId}/${Date.now()}.${fileExt}`;

    const { error: uploadError, data } = await supabase.storage
      .from('chat-files')
      .upload(fileName, file);

    if (uploadError) {
      console.error('Upload error:', uploadError);
      return null;
    }

    const { data: { publicUrl } } = supabase.storage
      .from('chat-files')
      .getPublicUrl(fileName);

    return publicUrl;
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const getAvatarUrl = useCallback((avatarPath: string | null) => {
    if (!avatarPath) return '';
    const { data } = supabase.storage
      .from('avatars')
      .getPublicUrl(avatarPath);
    return data.publicUrl;
  }, []);

  const getMessageInitials = (message: MessageWithProfile) => {
    if (message.sender_profile?.full_name) {
      return message.sender_profile.full_name
        .split(' ')
        .map(n => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);
    }
    return 'US';
  };

  const isUserOnline = (userId: string) => {
    return onlineUsers.has(userId);
  };

  const sendMessage = async () => {
    if (!proposal) return;

    let fileUrl: string | null = null;
    let fileName: string | null = null;
    let fileType: string | null = null;

    if (selectedFile) {
      setUploadingFile(true);
      fileUrl = await uploadFile(selectedFile);
      
      if (!fileUrl) {
        toast({
          title: 'Ошибка',
          description: 'Не удалось загрузить файл',
          variant: 'destructive',
        });
        setUploadingFile(false);
        return;
      }

      fileName = selectedFile.name;
      fileType = selectedFile.type;
      setUploadingFile(false);
    }

    if (!newMessage.trim() && !fileUrl) {
      toast({
        title: 'Ошибка',
        description: 'Сообщение не может быть пустым',
        variant: 'destructive',
      });
      return;
    }

    // If editing, update the message
    if (editingMessageId) {
      await saveEdit();
      return;
    }

    // Validate message input if there's text
    if (newMessage.trim()) {
      const validation = messageSchema.safeParse({ message: newMessage });
      if (!validation.success) {
        toast({
          title: 'Ошибка',
          description: validation.error.errors[0].message,
          variant: 'destructive',
        });
        return;
      }
    }

    const { error } = await supabase
      .from('proposal_messages')
      .insert({
        proposal_id: id,
        sender_id: currentUserId,
        message: newMessage || (fileName ? `📎 ${fileName}` : ''),
        file_url: fileUrl,
        file_name: fileName,
        file_type: fileType,
      });

    if (error) {
      toast({
        title: 'Ошибка',
        description: 'Не удалось отправить сообщение',
        variant: 'destructive',
      });
      return;
    }

    // Create notification for the other party (only admins can create notifications)
    if (isAdmin) {
      const recipientId = proposal.user_id;
      await supabase.rpc('create_notification', {
        _user_id: recipientId,
        _title: 'У вас новое сообщение',
        _message: `Новое сообщение по предложению: ${proposal.title}`,
        _proposal_id: id,
      });
    }

    setNewMessage('');
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const startEditing = (message: Message) => {
    setEditingMessageId(message.id);
    setNewMessage(message.message);
  };

  const cancelEditing = () => {
    setEditingMessageId(null);
    setNewMessage('');
  };

  const saveEdit = async () => {
    if (!editingMessageId) return;

    const validation = messageSchema.safeParse({ message: newMessage });
    if (!validation.success) {
      toast({
        title: 'Ошибка',
        description: validation.error.errors[0].message,
        variant: 'destructive',
      });
      return;
    }

    const { error } = await supabase
      .from('proposal_messages')
      .update({ 
        message: validation.data.message,
        edited_at: new Date().toISOString()
      })
      .eq('id', editingMessageId);

    if (error) {
      toast({
        title: 'Ошибка',
        description: 'Не удалось обновить сообщение',
        variant: 'destructive',
      });
      return;
    }

    setEditingMessageId(null);
    setNewMessage('');
    toast({
      title: 'Успешно',
      description: 'Сообщение обновлено',
    });
  };

  const deleteMessage = async (messageId: string) => {
    // Оптимистичное обновление - сразу удаляем из UI
    setMessages(prev => prev.filter(msg => msg.id !== messageId));
    setDeletingMessageId(null);

    const { error } = await supabase
      .from('proposal_messages')
      .delete()
      .eq('id', messageId);

    if (error) {
      // В случае ошибки восстанавливаем сообщения
      fetchMessages();
      toast({
        title: 'Ошибка',
        description: 'Не удалось удалить сообщение',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Успешно',
      description: 'Сообщение удалено',
    });
  };

  if (embedded) {
    return (
      <div className="flex flex-col h-full">
        <div className="p-4 border-b">
          {otherUserName && (
            <h2 className="font-semibold">{otherUserName}</h2>
          )}
          <p className="text-sm text-muted-foreground">{proposal?.title}</p>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex group ${
                message.sender_id === currentUserId ? 'justify-end' : 'justify-start'
              }`}
            >
              <div className="flex items-start gap-2 max-w-[70%]">
                {message.sender_id !== currentUserId && (
                  <div className="relative">
                    <Avatar className="w-8 h-8 shrink-0">
                      <AvatarImage src={getAvatarUrl(message.sender_profile?.avatar_url || null)} />
                      <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                        {getMessageInitials(message)}
                      </AvatarFallback>
                    </Avatar>
                    {isUserOnline(message.sender_id) && (
                      <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-background" />
                    )}
                  </div>
                )}
                
                <div className="flex flex-col gap-1">
                  {message.sender_id === currentUserId && (
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity self-end">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => startEditing(message)}
                      >
                        <Pencil className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 text-destructive"
                        onClick={() => setDeletingMessageId(message.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                  
                  <div
                    className={`rounded-lg p-3 ${
                      message.sender_id === currentUserId
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}
                  >
                  {message.file_url && (
                    <div className="mb-2">
                      {message.file_type?.startsWith('image/') ? (
                        <a href={message.file_url} target="_blank" rel="noopener noreferrer">
                          <img 
                            src={message.file_url} 
                            alt={message.file_name || 'Image'} 
                            className="max-w-full rounded cursor-pointer hover:opacity-90"
                            style={{ maxHeight: '300px' }}
                          />
                        </a>
                      ) : (
                        <a 
                          href={message.file_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 p-2 rounded bg-background/10 hover:bg-background/20 transition-colors"
                        >
                          <FileText className="h-4 w-4" />
                          <span className="text-sm">{message.file_name}</span>
                        </a>
                      )}
                    </div>
                  )}
                  {message.message && (
                    <p className="text-sm">{message.message}</p>
                  )}
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-xs opacity-70">
                      {new Date(message.created_at).toLocaleTimeString('ru-RU', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                    {message.edited_at && (
                      <span className="text-xs opacity-70">ред.</span>
                    )}
                   </div>
                 </div>
               </div>

                {message.sender_id === currentUserId && (
                  <div className="relative">
                    <Avatar className="w-8 h-8 shrink-0">
                      <AvatarImage src={getAvatarUrl(message.sender_profile?.avatar_url || null)} />
                      <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                        {getMessageInitials(message)}
                      </AvatarFallback>
                    </Avatar>
                    {isUserOnline(message.sender_id) && (
                      <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-background" />
                    )}
                  </div>
                )}
             </div>
           </div>
         ))}
         <div ref={messagesEndRef} />
        </div>

        <div className="p-4 border-t">
          {editingMessageId && (
            <div className="mb-2 flex items-center justify-between p-2 bg-muted rounded-md">
              <div className="flex items-center gap-2">
                <Pencil className="h-4 w-4" />
                <span className="text-sm">Редактирование сообщения</span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={cancelEditing}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          )}
          <div className="flex flex-col gap-2">
            {selectedFile && (
              <div className="flex items-center gap-2 p-2 bg-muted rounded">
                {selectedFile.type.startsWith('image/') ? (
                  <ImageIcon className="h-4 w-4" />
                ) : (
                  <FileText className="h-4 w-4" />
                )}
                <span className="text-sm flex-1">{selectedFile.name}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSelectedFile(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}
            <div className="flex gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
                onChange={handleFileSelect}
                className="hidden"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploadingFile}
              >
                <Paperclip className="h-4 w-4" />
              </Button>
              <Textarea
                placeholder="Введите сообщение..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
                className="resize-none"
                rows={2}
              />
              <Button 
                onClick={sendMessage} 
                size="icon" 
                className="self-end"
                disabled={uploadingFile}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <AlertDialog open={!!deletingMessageId} onOpenChange={() => setDeletingMessageId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Удалить сообщение?</AlertDialogTitle>
              <AlertDialogDescription>
                Это действие нельзя отменить. Сообщение будет удалено.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Отмена</AlertDialogCancel>
              <AlertDialogAction onClick={() => deletingMessageId && deleteMessage(deletingMessageId)}>
                Удалить
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-4"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Назад
        </Button>

        <Card className="p-6">
          <div className="mb-6">
            {otherUserName && (
              <h1 className="text-2xl font-bold mb-2">{otherUserName}</h1>
            )}
            <p className="text-lg font-medium text-muted-foreground">{proposal?.title}</p>
          </div>

          <div className="h-[500px] overflow-y-auto mb-4 space-y-4 border rounded-lg p-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex group ${
                  message.sender_id === currentUserId ? 'justify-end' : 'justify-start'
                }`}
              >
                <div className="flex items-start gap-2 max-w-[70%]">
                  {message.sender_id !== currentUserId && (
                    <div className="relative">
                      <Avatar className="w-8 h-8 shrink-0">
                        <AvatarImage src={getAvatarUrl(message.sender_profile?.avatar_url || null)} />
                        <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                          {getMessageInitials(message)}
                        </AvatarFallback>
                      </Avatar>
                      {isUserOnline(message.sender_id) && (
                        <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-background" />
                      )}
                    </div>
                  )}
                  
                  <div className="flex flex-col gap-1">
                    {message.sender_id === currentUserId && (
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity self-end">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => startEditing(message)}
                        >
                          <Pencil className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-destructive"
                          onClick={() => setDeletingMessageId(message.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                    
                    <div
                      className={`rounded-lg p-3 ${
                        message.sender_id === currentUserId
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                    {message.file_url && (
                      <div className="mb-2">
                        {message.file_type?.startsWith('image/') ? (
                          <a href={message.file_url} target="_blank" rel="noopener noreferrer">
                            <img 
                              src={message.file_url} 
                              alt={message.file_name || 'Image'} 
                              className="max-w-full rounded cursor-pointer hover:opacity-90"
                              style={{ maxHeight: '300px' }}
                            />
                          </a>
                        ) : (
                          <a 
                            href={message.file_url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 p-2 rounded bg-background/10 hover:bg-background/20 transition-colors"
                          >
                            <FileText className="h-4 w-4" />
                            <span className="text-sm">{message.file_name}</span>
                          </a>
                        )}
                      </div>
                    )}
                    {message.message && (
                      <p className="text-sm">{message.message}</p>
                    )}
                    <div className="flex items-center gap-2 mt-1">
                      <p className="text-xs opacity-70">
                        {new Date(message.created_at).toLocaleTimeString('ru-RU', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                      {message.edited_at && (
                        <span className="text-xs opacity-70">ред.</span>
                      )}
                     </div>
                   </div>
                 </div>

                  {message.sender_id === currentUserId && (
                    <div className="relative">
                      <Avatar className="w-8 h-8 shrink-0">
                        <AvatarImage src={getAvatarUrl(message.sender_profile?.avatar_url || null)} />
                        <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                          {getMessageInitials(message)}
                        </AvatarFallback>
                      </Avatar>
                      {isUserOnline(message.sender_id) && (
                        <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-background" />
                      )}
                    </div>
                  )}
               </div>
             </div>
           ))}
           <div ref={messagesEndRef} />
         </div>

          {editingMessageId && (
            <div className="mb-2 flex items-center justify-between p-2 bg-muted rounded-md">
              <div className="flex items-center gap-2">
                <Pencil className="h-4 w-4" />
                <span className="text-sm">Редактирование сообщения</span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={cancelEditing}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          )}

          <div className="flex flex-col gap-2">
            {selectedFile && (
              <div className="flex items-center gap-2 p-2 bg-muted rounded">
                {selectedFile.type.startsWith('image/') ? (
                  <ImageIcon className="h-4 w-4" />
                ) : (
                  <FileText className="h-4 w-4" />
                )}
                <span className="text-sm flex-1">{selectedFile.name}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSelectedFile(null);
                    if (fileInputRef.current) fileInputRef.current.value = '';
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}
            <div className="flex gap-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
                onChange={handleFileSelect}
                className="hidden"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploadingFile}
              >
                <Paperclip className="h-4 w-4" />
              </Button>
              <Textarea
                placeholder="Введите сообщение..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                  }
                }}
                className="resize-none"
                rows={3}
              />
              <Button 
                onClick={sendMessage} 
                size="icon" 
                className="self-end"
                disabled={uploadingFile}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>

        <AlertDialog open={!!deletingMessageId} onOpenChange={() => setDeletingMessageId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Удалить сообщение?</AlertDialogTitle>
              <AlertDialogDescription>
                Это действие нельзя отменить. Сообщение будет удалено.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Отмена</AlertDialogCancel>
              <AlertDialogAction onClick={() => deletingMessageId && deleteMessage(deletingMessageId)}>
                Удалить
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
