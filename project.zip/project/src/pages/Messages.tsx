import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate, useParams } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { MessageSquare, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import ProposalChat from './ProposalChat';

interface Chat {
  proposal_id: string;
  proposal_title: string;
  last_message: string;
  last_message_time: string;
  unread_count: number;
  other_user_id: string;
  other_user_name: string;
  other_user_avatar: string | null;
}

export default function Messages() {
  const [chats, setChats] = useState<Chat[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string>('');
  const [isAdmin, setIsAdmin] = useState(false);
  const navigate = useNavigate();
  const { id } = useParams();

  useEffect(() => {
    fetchChats();
    checkAdmin();

    // Subscribe to new messages - debounce to avoid too many fetches
    let timeout: NodeJS.Timeout;
    const channel = supabase
      .channel('proposal_messages_list')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'proposal_messages',
        },
        () => {
          clearTimeout(timeout);
          timeout = setTimeout(() => fetchChats(), 500);
        }
      )
      .subscribe();

    return () => {
      clearTimeout(timeout);
      supabase.removeChannel(channel);
    };
  }, []);

  const checkAdmin = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    setCurrentUserId(user.id);

    // Client-side check for UX only - actual authorization enforced by RLS
    const { data: roles } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    setIsAdmin(roles?.role === 'admin');
  };

  const fetchChats = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    // Get all proposals where user has messages
    const { data: messages } = await supabase
      .from('proposal_messages')
      .select(`
        proposal_id,
        message,
        created_at,
        sender_id,
        proposals!inner(
          id,
          title,
          user_id
        )
      `)
      .order('created_at', { ascending: false });

    if (!messages) return;

    // Group messages by proposal
    const chatMap = new Map<string, Chat>();

    for (const msg of messages) {
      const proposal = msg.proposals as any;
      const proposalId = msg.proposal_id;

      // Check if user is part of this conversation
      const isUserProposalAuthor = proposal.user_id === user.id;
      const isUserMessageSender = msg.sender_id === user.id;
      
      if (!isUserProposalAuthor && !isUserMessageSender) continue;

      if (!chatMap.has(proposalId)) {
        const otherUserId = proposal.user_id === user.id ? msg.sender_id : proposal.user_id;
        
        // Fetch other user's name and avatar
        let otherUserName = 'Пользователь';
        let otherUserAvatar: string | null = null;
        
        const { data: profile } = await supabase
          .from('profiles')
          .select('full_name, email, avatar_url')
          .eq('id', otherUserId)
          .maybeSingle();
        
        if (profile) {
          otherUserName = profile.full_name || profile.email || 'Пользователь';
          otherUserAvatar = profile.avatar_url;
        }
        
        // For regular users, show "Администратор" instead of actual admin name
        if (!isAdmin) {
          otherUserName = 'Администратор';
        }
        
        chatMap.set(proposalId, {
          proposal_id: proposalId,
          proposal_title: proposal.title,
          last_message: msg.message,
          last_message_time: msg.created_at,
          unread_count: 0,
          other_user_id: otherUserId,
          other_user_name: otherUserName,
          other_user_avatar: otherUserAvatar,
        });
      }
    }

    setChats(Array.from(chatMap.values()));
  };

  const handleChatClick = (proposalId: string) => {
    navigate(`/messages/${proposalId}`);
  };

  const getAvatarUrl = (avatarPath: string | null) => {
    if (!avatarPath) return '';
    const { data } = supabase.storage
      .from('avatars')
      .getPublicUrl(avatarPath);
    return data.publicUrl;
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="flex h-[calc(100vh-2rem)] gap-4">
      {/* Chat List */}
      <Card className={`flex flex-col ${id ? 'w-80' : 'flex-1'} transition-all`}>
        <div className="p-4 border-b">
          <h2 className="text-xl font-bold">Сообщения</h2>
        </div>

        <div className="flex-1 overflow-y-auto">
          {chats.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Нет сообщений</h3>
              <p className="text-sm text-muted-foreground">
                Здесь будут отображаться ваши переписки по предложениям
              </p>
            </div>
          ) : (
            <div className="divide-y">
              {chats.map((chat) => (
                <div
                  key={chat.proposal_id}
                  onClick={() => handleChatClick(chat.proposal_id)}
                  className={`p-4 cursor-pointer hover:bg-cyan-500/20 transition-colors ${
                    id === chat.proposal_id ? 'bg-cyan-500/20' : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <Avatar className="w-10 h-10 flex-shrink-0">
                      <AvatarImage 
                        src={getAvatarUrl(chat.other_user_avatar)} 
                        alt={chat.other_user_name}
                        className="object-cover"
                      />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {getInitials(chat.other_user_name)}
                      </AvatarFallback>
                    </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h3 className="font-semibold text-sm truncate">
                        {chat.other_user_name}
                      </h3>
                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                        {new Date(chat.last_message_time).toLocaleTimeString('ru-RU', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">
                      <span className="font-medium">Тема:</span> {chat.proposal_title}
                    </p>
                  </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Card>

      {/* Chat View */}
      {id ? (
        <Card className="flex-1 flex flex-col">
          <div className="p-4 border-b flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/messages')}
              className="lg:hidden"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <h2 className="text-lg font-semibold">Чат по предложению</h2>
          </div>
          <div className="flex-1 overflow-hidden">
            <ProposalChat embedded />
          </div>
        </Card>
      ) : (
        <Card className="hidden lg:flex flex-1 items-center justify-center">
          <div className="text-center">
            <MessageSquare className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Выберите чат</h3>
            <p className="text-muted-foreground">
              Выберите переписку из списка слева
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}
