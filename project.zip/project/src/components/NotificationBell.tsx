import { useState, useEffect } from 'react';
import { Bell } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from '@/components/ui/hover-card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface Notification {
  id: string;
  title: string;
  message: string;
  read: boolean;
  proposal_id: string | null;
  created_at: string;
}

export const NotificationBell = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    fetchNotifications();

    // Subscribe to new notifications
    const channel = supabase
      .channel('notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
        },
        () => {
          fetchNotifications();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchNotifications = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(10);

    if (data) {
      setNotifications(data);
      setUnreadCount(data.filter(n => !n.read).length);
    }
  };

  const markAsRead = async (notificationId: string, proposalId: string | null) => {
    await supabase
      .from('notifications')
      .update({ read: true })
      .eq('id', notificationId);

    if (proposalId) {
      navigate(`/messages/${proposalId}`);
    }
    
    fetchNotifications();
  };

  return (
    <HoverCard openDelay={200}>
      <HoverCardTrigger asChild>
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate('/notifications')}
          className="relative h-11 w-11"
        >
          <Bell className="h-7 w-7" />
          {unreadCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
            >
              {unreadCount}
            </Badge>
          )}
        </Button>
      </HoverCardTrigger>
      <HoverCardContent align="start" className="w-80 p-0">
        {notifications.filter(n => !n.read).length === 0 ? (
          <div className="p-4 text-center text-sm text-muted-foreground">
            Нет новых уведомлений
          </div>
        ) : (
          <div className="max-h-96 overflow-y-auto">
            {notifications.filter(n => !n.read).slice(0, 5).map((notification) => (
              <div
                key={notification.id}
                onClick={() => markAsRead(notification.id, notification.proposal_id)}
                className="flex flex-col items-start p-4 cursor-pointer border-b border-l-4 border-l-destructive hover:bg-cyan-500/20 transition-colors last:border-b-0"
              >
                <div className="font-semibold">{notification.title}</div>
                <div className="text-sm text-muted-foreground">{notification.message}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  {new Date(notification.created_at).toLocaleString('ru-RU')}
                </div>
              </div>
            ))}
          </div>
        )}
      </HoverCardContent>
    </HoverCard>
  );
};
