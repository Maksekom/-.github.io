-- Add edited_at column to proposal_messages table
ALTER TABLE public.proposal_messages 
ADD COLUMN edited_at timestamp with time zone;