import { MoreHorizontal, Edit, Star, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import BannerCarousel from "@/components/BannerCarousel";
import shopBox from "@/assets/shop-box.png";
import shopHoodie from "@/assets/shop-hoodie.png";
import shopTshirt from "@/assets/shop-tshirt.png";
import shopShopper from "@/assets/shop-shopper.png";
import leader1 from "@/assets/leader-1.png";
import leader2 from "@/assets/leader-2.png";
import leader3 from "@/assets/leader-3.png";
import leader4 from "@/assets/leader-4.png";
import leader5 from "@/assets/leader-5.png";
import leader6 from "@/assets/leader-6.png";
import offerAuto from "@/assets/offer-auto.png";
import offerBetting from "@/assets/offer-betting.png";
import offerEfficiency from "@/assets/offer-efficiency.png";
import offerImprove from "@/assets/offer-improve.png";

const Home = () => {
  const navigate = useNavigate();
  const proposals = [
    { id: "#876369", title: "Улучшение камер", budget: "100 тыс.", resources: 1, status: "Идея сырая", image: offerImprove },
    { id: "#876368", title: "Повышение КПД", budget: "0", resources: 0, status: "Идея почти разработана", image: offerEfficiency },
    { id: "#876367", title: "Станки", budget: "2 млн.", resources: 5, status: "Идея сырая", image: offerBetting },
    { id: "#876366", title: "Авто", budget: "500 тыс.", resources: 4, status: "Готова к обсуждению", image: offerAuto },
  ];

  const leaderboard = [
    { name: "Елена Романова", color: "bg-yellow-400", status: "", image: leader1 },
    { name: "Кристина Дмитрова", color: "bg-gray-300", status: "Начальник ФЭС", image: leader2 },
    { name: "Анатолий Разин", color: "bg-orange-500", status: "Охранник", image: leader3 },
    { name: "Владимир Филин", color: "bg-white border border-border", status: "Водитель", image: leader4 },
    { name: "Маргарита Леонтьева", color: "bg-white border border-border", status: "Уборщица", image: leader5 },
    { name: "Лев Баринов", color: "bg-white border border-border", status: "Генеральный директор", image: leader6 },
  ];

  const shopItems = [
    { name: "Худи ПЭК", price: "150 ПЭКОВ", image: shopHoodie },
    { name: "Футболка ПЭК", price: "100 ПЭКОВ", image: shopTshirt },
    { name: "Бокс ПЭК", price: "20 ПЭКОВ", image: shopBox },
    { name: "Шоппер ПЭК", price: "50 ПЭКОВ", image: shopShopper },
  ];

  return (
    <div className="space-y-6">
      {/* Hero Banner - Full Width */}
      <BannerCarousel slides={[
        {
          title: "КУПИ МЕРЧ ТОЛЬКО СЕГОДНЯ",
          subtitle: "СО СКИДКОЙ В 20%",
          description: "Не упусти момент - все зависит от твоих идей",
          buttonText: "КУПИТЬ",
          buttonLink: "/shop"
        },
        {
          title: "ТВОИ ИДЕИ -",
          subtitle: "НАШЕ СОВМЕСТНОЕ БУДУЩЕЕ",
          description: "Помоги компании развиваться вместе с тобой",
          buttonText: "ПРЕДЛОЖИТЬ",
          buttonLink: "/proposals/new"
        },
        {
          title: "МОИ ПРЕДЛОЖЕНИЯ -",
          subtitle: "ОТСЛЕЖИВАЙ СТАТУС",
          description: "Смотри, что происходит с твоими идеями",
          buttonText: "СМОТРЕТЬ",
          buttonLink: "/proposals"
        }
      ]} />

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_500px] lg:auto-rows-min gap-6">
        {/* Proposals Section */}
        <Card className="p-6 lg:col-start-1 lg:row-start-1">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold">Последние предложения</h2>
            <MoreHorizontal className="w-5 h-5 text-muted-foreground cursor-pointer" />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border text-sm text-muted-foreground">
                  <th className="text-left py-3 font-medium">Номер предложения</th>
                  <th className="text-left py-3 font-medium">Название предложения</th>
                  <th className="text-left py-3 font-medium">Бюджет</th>
                  <th className="text-left py-3 font-medium">Ресурсы</th>
                  <th className="text-left py-3 font-medium">Уровень проработки</th>
                </tr>
              </thead>
              <tbody>
                {proposals.map((proposal) => (
                  <tr key={proposal.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                    <td className="py-4">
                      <span className="text-primary cursor-pointer hover:underline">{proposal.id}</span>
                    </td>
                    <td className="py-4 flex items-center gap-3">
                      <div className="w-10 h-10 bg-muted rounded flex items-center justify-center overflow-hidden">
                        <img src={proposal.image} alt={proposal.title} className="w-full h-full object-cover" />
                      </div>
                      <span>{proposal.title}</span>
                    </td>
                    <td className="py-4">{proposal.budget}</td>
                    <td className="py-4">
                      <Badge className="bg-primary text-primary-foreground">
                        {proposal.resources}
                      </Badge>
                    </td>
                    <td className="py-4 text-sm text-muted-foreground">{proposal.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Shop Section */}
        <Card className="p-6 lg:col-start-1 lg:row-start-2">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold">Магазин</h2>
            <MoreHorizontal className="w-5 h-5 text-muted-foreground cursor-pointer" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {shopItems.slice(0, 3).map((item, index) => (
              <Card 
                key={index} 
                className="p-0 overflow-hidden border-border flex flex-row h-[160px] cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => navigate('/shop')}
              >
                <div className="w-[160px] h-full bg-muted/20 flex items-center justify-center relative flex-shrink-0">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="p-4 flex flex-col justify-center">
                  <h3 className="font-medium text-base mb-2">{item.name}</h3>
                  <p className="text-xl font-bold text-primary">{item.price}</p>
                </div>
              </Card>
            ))}
          </div>
        </Card>

      {/* Leaderboard Section */}
        <Card className="p-6 lg:col-start-2 lg:row-start-1 lg:row-span-2">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold">Лидер борд</h2>
            <select className="text-sm border border-border rounded px-2 py-1 bg-background">
              <option>Сортировать по количеству</option>
            </select>
          </div>

          <div className="space-y-3 mb-6">
            {leaderboard.map((user, index) => (
              <div key={index} className={`flex items-center gap-3 p-3 rounded-lg ${user.color}`}>
                <Avatar className="w-10 h-10">
                  <AvatarImage src={user.image} alt={user.name} />
                  <AvatarFallback>{user.name.substring(0, 2)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{user.name}</div>
                  {user.status && <div className="text-xs text-muted-foreground truncate">{user.status}</div>}
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button className="w-8 h-8 rounded-full hover:bg-background/10 flex items-center justify-center transition-colors">
                    <MessageCircle className="w-4 h-4" />
                  </button>
                  <button className="w-8 h-8 rounded-full hover:bg-background/10 flex items-center justify-center transition-colors">
                    <Star className="w-4 h-4" />
                  </button>
                  <button className="w-8 h-8 rounded-full hover:bg-background/10 flex items-center justify-center transition-colors">
                    <Edit className="w-4 h-4" />
                  </button>
                  <button className="w-8 h-8 rounded-full hover:bg-background/10 flex items-center justify-center transition-colors">
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-border pt-4">
            <Button variant="link" className="w-full text-primary">
              Полный список →
            </Button>
          </div>
        </Card>
    </div>
  </div>
  );
};

export default Home;
