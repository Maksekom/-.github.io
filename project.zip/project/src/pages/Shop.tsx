import { ChevronLeft, ChevronRight, Heart, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import BannerCarousel from "@/components/BannerCarousel";
import shopBox from "@/assets/shop-box.png";
import shopHoodie from "@/assets/shop-hoodie.png";
import shopTshirt from "@/assets/shop-tshirt.png";
import shopShopper from "@/assets/shop-shopper.png";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

const Shop = () => {
  const { toast } = useToast();
  const [likedProducts, setLikedProducts] = useState<Set<number>>(new Set());
  
  const products = [
    { 
      name: "Бокс ПЭК", 
      price: 20,
      image: shopBox
    },
    { 
      name: "Худи ПЭК", 
      price: 150,
      image: shopHoodie
    },
    { 
      name: "Футболка ПЭК", 
      price: 100,
      image: shopTshirt
    },
    { 
      name: "Шоппер ПЭК", 
      price: 50,
      image: shopShopper
    },
    { 
      name: "Бокс ПЭК", 
      price: 20,
      image: shopBox
    },
    { 
      name: "Худи ПЭК", 
      price: 150,
      image: shopHoodie
    },
    { 
      name: "Футболка ПЭК", 
      price: 100,
      image: shopTshirt
    },
    { 
      name: "Шоппер ПЭК", 
      price: 50,
      image: shopShopper
    },
  ];

  const toggleLike = (index: number) => {
    setLikedProducts(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  };

  const addToCart = async (product: typeof products[0]) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast({
          title: "Ошибка",
          description: "Необходимо войти в систему",
          variant: "destructive",
          duration: 3000,
        });
        return;
      }

      // Check if item already exists in cart
      const { data: existingItem } = await supabase
        .from("cart_items")
        .select("*")
        .eq("user_id", user.id)
        .eq("product_name", product.name)
        .maybeSingle();

      if (existingItem) {
        // Update quantity
        const { error } = await supabase
          .from("cart_items")
          .update({ quantity: existingItem.quantity + 1 })
          .eq("id", existingItem.id);

        if (error) throw error;
      } else {
        // Insert new item
        const { error } = await supabase
          .from("cart_items")
          .insert({
            user_id: user.id,
            product_name: product.name,
            product_price: product.price,
            product_image: product.image,
            quantity: 1,
          });

        if (error) throw error;
      }

      // Notify cart to update
      window.dispatchEvent(new Event('cartUpdated'));
      
      toast({
        title: "Добавлено в корзину",
        description: `${product.name} добавлен в корзину`,
        duration: 3000,
      });
    } catch (error) {
      console.error("Error adding to cart:", error);
      toast({
        title: "Ошибка",
        description: "Не удалось добавить товар в корзину",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <BannerCarousel slides={[
        {
          title: "СКОРЕЕ СМОТРИ -",
          subtitle: "НА ТВОЕ ПРЕДЛОЖЕНИЕ УЖЕ ОТВЕТИЛИ",
          description: "Ответ на каждое предложение не занимает и часа!",
          buttonText: "СМОТРЕТЬ",
          buttonLink: "/proposals"
        },
        {
          title: "ТВОИ ИДЕИ -",
          subtitle: "НАШЕ СОВМЕСТНОЕ БУДУЩЕЕ",
          description: "Помоги компании развиваться вместе с тобой",
          buttonText: "ПРЕДЛОЖИТЬ",
          buttonLink: "/proposals/new"
        }
      ]} />

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map((product, index) => (
          <Card key={index} className="overflow-hidden group">
            <div className="relative bg-gradient-to-br from-muted/20 to-muted/30">
              {/* Product Image */}
              <div className="aspect-square flex items-center justify-center relative">
                <button className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background shadow-md hover:shadow-lg flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 z-10">
                  <ChevronLeft className="w-4 h-4 text-foreground" />
                </button>
                
                <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                
                <button className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-background shadow-md hover:shadow-lg flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 z-10">
                  <ChevronRight className="w-4 h-4 text-foreground" />
                </button>

                {/* Favorite Button */}
                <button 
                  onClick={() => toggleLike(index)}
                  className="absolute top-4 right-4 w-10 h-10 rounded-full bg-background shadow-md hover:shadow-lg flex items-center justify-center transition-all z-10"
                >
                  <Heart 
                    className={`w-5 h-5 transition-colors ${
                      likedProducts.has(index) 
                        ? "text-red-500 fill-red-500" 
                        : "text-muted-foreground"
                    }`} 
                  />
                </button>
              </div>
            </div>

            <div className="p-4">
              <h3 className="font-semibold text-lg mb-1">{product.name}</h3>
              <p className="text-muted-foreground mb-4">{product.price} ПЭКОВ</p>
              <Button 
                className="w-full"
                onClick={() => addToCart(product)}
              >
                Приобрести
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Shop;
