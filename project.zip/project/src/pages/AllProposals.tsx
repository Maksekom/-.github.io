import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface Proposal {
  id: string;
  title: string;
  budget: string | null;
  resources: string | null;
  full_name: string | null;
  status: string;
  anonymous_until_review: boolean | null;
}

const AllProposals = () => {
  const navigate = useNavigate();
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProposals();
  }, []);

  const fetchProposals = async () => {
    try {
      const { data, error } = await supabase
        .from("proposals")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;

      setProposals(data || []);
    } catch (error) {
      console.error("Error fetching proposals:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusLabel = (status: string) => {
    const statusMap: Record<string, string> = {
      pending: "Рассмотреть",
      approved: "Одобрена",
      rejected: "Отклонена",
      in_discussion: "Обсуждается",
    };
    return statusMap[status] || status;
  };

  const getStatusVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
    const variantMap: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
      pending: "outline",
      approved: "default",
      rejected: "destructive",
      in_discussion: "secondary",
    };
    return variantMap[status] || "outline";
  };

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <Card className="bg-hero-gradient text-white p-8 relative overflow-hidden border-0">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{ 
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` 
          }} />
        </div>
        
        <div className="relative z-10">
          <div className="text-sm mb-2">26 октября 2025</div>
          <h1 className="text-4xl font-bold mb-3">СКОРЕЕ СМОТРИ - НА ТВОЕ<br />ПРЕДЛОЖЕНИЕ УЖЕ ОТВЕТИЛИ</h1>
          <p className="text-white/90 mb-6">Ответ на каждое предложение не занимает и часа!</p>
          <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-medium">
            СМОТРЕТЬ
          </Button>
        </div>

        <button className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors">
          <ChevronRight className="w-5 h-5" />
        </button>
      </Card>

      {/* All Proposals Table */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h2 className="text-xl font-semibold mb-6">Все предложения</h2>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border text-sm text-muted-foreground">
                <th className="text-left py-3 px-4 font-medium">Имя</th>
                <th className="text-left py-3 px-4 font-medium">Номер</th>
                <th className="text-left py-3 px-4 font-medium">Название</th>
                <th className="text-left py-3 px-4 font-medium">Бюджет</th>
                <th className="text-left py-3 px-4 font-medium">Ресурсы</th>
                <th className="text-right py-3 px-4 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-muted-foreground">
                    Загрузка...
                  </td>
                </tr>
              ) : proposals.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-muted-foreground">
                    Нет предложений
                  </td>
                </tr>
              ) : (
                proposals.map((proposal) => (
                  <tr 
                    key={proposal.id}
                    className="border-b border-border hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => navigate(`/admin/proposals/${proposal.id}`)}
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-9 h-9">
                          <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                            {(proposal.anonymous_until_review && proposal.status === "pending") 
                              ? "??" 
                              : (proposal.full_name?.substring(0, 2).toUpperCase() || "??")}
                          </AvatarFallback>
                        </Avatar>
                        <span className="font-medium">
                          {(proposal.anonymous_until_review && proposal.status === "pending") 
                            ? "Аноним" 
                            : (proposal.full_name || "Аноним")}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-primary">#{proposal.id.substring(0, 6)}</span>
                    </td>
                    <td className="py-4 px-4">{proposal.title}</td>
                    <td className="py-4 px-4">{proposal.budget || "-"}</td>
                    <td className="py-4 px-4">
                      <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground text-sm font-medium">
                        {proposal.resources || "0"}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <Badge variant={getStatusVariant(proposal.status)}>
                        {getStatusLabel(proposal.status)}
                      </Badge>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AllProposals;
