-- Drop existing foreign keys and recreate them with ON DELETE CASCADE

-- proposals table
ALTER TABLE public.proposals 
DROP CONSTRAINT IF EXISTS proposals_user_id_fkey;

ALTER TABLE public.proposals
ADD CONSTRAINT proposals_user_id_fkey 
FOREIGN KEY (user_id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;

-- proposal_comments table
ALTER TABLE public.proposal_comments 
DROP CONSTRAINT IF EXISTS proposal_comments_user_id_fkey;

ALTER TABLE public.proposal_comments
ADD CONSTRAINT proposal_comments_user_id_fkey 
FOREIGN KEY (user_id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;

ALTER TABLE public.proposal_comments 
DROP CONSTRAINT IF EXISTS proposal_comments_proposal_id_fkey;

ALTER TABLE public.proposal_comments
ADD CONSTRAINT proposal_comments_proposal_id_fkey 
FOREIGN KEY (proposal_id) 
REFERENCES public.proposals(id) 
ON DELETE CASCADE;

-- proposal_messages table
ALTER TABLE public.proposal_messages 
DROP CONSTRAINT IF EXISTS proposal_messages_sender_id_fkey;

ALTER TABLE public.proposal_messages
ADD CONSTRAINT proposal_messages_sender_id_fkey 
FOREIGN KEY (sender_id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;

ALTER TABLE public.proposal_messages 
DROP CONSTRAINT IF EXISTS proposal_messages_proposal_id_fkey;

ALTER TABLE public.proposal_messages
ADD CONSTRAINT proposal_messages_proposal_id_fkey 
FOREIGN KEY (proposal_id) 
REFERENCES public.proposals(id) 
ON DELETE CASCADE;

-- notifications table
ALTER TABLE public.notifications 
DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;

ALTER TABLE public.notifications
ADD CONSTRAINT notifications_user_id_fkey 
FOREIGN KEY (user_id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;

ALTER TABLE public.notifications 
DROP CONSTRAINT IF EXISTS notifications_proposal_id_fkey;

ALTER TABLE public.notifications
ADD CONSTRAINT notifications_proposal_id_fkey 
FOREIGN KEY (proposal_id) 
REFERENCES public.proposals(id) 
ON DELETE CASCADE;

-- cart_items table
ALTER TABLE public.cart_items 
DROP CONSTRAINT IF EXISTS cart_items_user_id_fkey;

ALTER TABLE public.cart_items
ADD CONSTRAINT cart_items_user_id_fkey 
FOREIGN KEY (user_id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;

-- user_balance table
ALTER TABLE public.user_balance 
DROP CONSTRAINT IF EXISTS user_balance_user_id_fkey;

ALTER TABLE public.user_balance
ADD CONSTRAINT user_balance_user_id_fkey 
FOREIGN KEY (user_id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;

-- user_roles table
ALTER TABLE public.user_roles 
DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;

ALTER TABLE public.user_roles
ADD CONSTRAINT user_roles_user_id_fkey 
FOREIGN KEY (user_id) 
REFERENCES auth.users(id) 
ON DELETE CASCADE;

-- profiles table already has ON DELETE CASCADE in the schema