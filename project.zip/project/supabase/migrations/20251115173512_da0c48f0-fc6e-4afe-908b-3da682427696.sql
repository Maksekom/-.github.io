-- Fix notification spoofing vulnerability
-- Drop the insecure policy that allows any authenticated user to insert notifications
DROP POLICY IF EXISTS "Authenticated users can insert notifications" ON public.notifications;

-- Add DELETE policy so users can manage their own notifications
CREATE POLICY "Users can delete their own notifications"
ON public.notifications
FOR DELETE
USING (auth.uid() = user_id);

-- Create a secure function for creating notifications
-- Only admins can create notifications for any user
CREATE OR REPLACE FUNCTION public.create_notification(
  _user_id uuid,
  _title text,
  _message text,
  _proposal_id uuid DEFAULT NULL,
  _type text DEFAULT 'info'
)
RETURNS uuid
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  notification_id uuid;
BEGIN
  -- Only admins can create notifications
  IF NOT has_role(auth.uid(), 'admin'::app_role) THEN
    RAISE EXCEPTION 'Unauthorized: Only admins can create notifications';
  END IF;
  
  -- Insert the notification and return the ID
  INSERT INTO public.notifications (user_id, title, message, proposal_id, type)
  VALUES (_user_id, _title, _message, _proposal_id, _type)
  RETURNING id INTO notification_id;
  
  RETURN notification_id;
END;
$$;