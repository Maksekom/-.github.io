import { Search, ChevronDown, LogOut, Shield, ArrowLeft, Settings, Coins } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate, useLocation } from "react-router-dom";
import { useEffect, useState, memo, useCallback } from "react";
import { NotificationBell } from "@/components/NotificationBell";
import Cart from "@/components/Cart";

const Header = memo(() => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isAdmin, setIsAdmin] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [userName, setUserName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [balance, setBalance] = useState(0);
  
  const canGoBack = location.pathname !== '/';

  const loadUserData = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    setUserEmail(user.email || "");

    // Load all data in parallel for better performance
    const [profileResult, rolesResult, balanceResult] = await Promise.all([
      supabase
        .from("profiles")
        .select("full_name, avatar_url")
        .eq("id", user.id)
        .maybeSingle(),
      supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .maybeSingle(),
      supabase
        .from("user_balance")
        .select("balance")
        .eq("user_id", user.id)
        .maybeSingle()
    ]);

    const profile = profileResult.data;
    const roles = rolesResult.data;
    const balanceData = balanceResult.data;

    if (profile) {
      setUserName(profile.full_name || "");
      if (profile.avatar_url) {
        const { data } = supabase.storage
          .from("avatars")
          .getPublicUrl(profile.avatar_url);
        setAvatarUrl(`${data.publicUrl}?t=${Date.now()}`);
      } else {
        setAvatarUrl("");
      }
    }

    if (roles && roles.role === "admin") {
      setIsAdmin(true);
    }

    if (balanceData) {
      setBalance(balanceData.balance);
    }
  }, []);

  useEffect(() => {
    loadUserData();

    // Listen for profile updates (name, avatar, etc.)
    const handleProfileUpdate = () => {
      loadUserData();
    };
    
    window.addEventListener('avatar-updated', handleProfileUpdate);
    window.addEventListener('profile-updated', handleProfileUpdate);

    return () => {
      window.removeEventListener('avatar-updated', handleProfileUpdate);
      window.removeEventListener('profile-updated', handleProfileUpdate);
    };
  }, [loadUserData]);

  const getInitials = useCallback(() => {
    if (userName) {
      return userName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    }
    if (userEmail) {
      return userEmail.slice(0, 2).toUpperCase();
    }
    return "US";
  }, [userName, userEmail]);

  const displayName = userName || userEmail;

  const handleLogout = useCallback(async () => {
    await supabase.auth.signOut();
    navigate("/login");
  }, [navigate]);

  return (
    <header className="h-16 bg-card/80 backdrop-blur-md border-b border-border/50 shadow-[0_2px_16px_rgba(0,0,0,0.08)] px-6 flex items-center justify-between sticky top-0 z-20">
      <div className="flex items-center gap-4 flex-1 max-w-2xl">
        {canGoBack && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="shrink-0"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
        )}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder="Поиск..."
            className="pl-10 bg-background border-border"
          />
        </div>
      </div>

      <div className="flex items-center gap-4 ml-6">
        <div className="flex items-center gap-2 text-sm px-3 py-1.5 bg-primary/10 rounded-lg">
          <Coins className="w-5 h-5 text-primary" />
          <span className="font-semibold text-foreground">{balance} ПЭК</span>
        </div>

        <div className="flex items-center gap-3 pl-4 border-l border-border">
          <Cart />
          <NotificationBell />
          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-3 cursor-pointer outline-none">
              <Avatar className="w-9 h-9">
                <AvatarImage src={avatarUrl} />
                <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                  {getInitials()}
                </AvatarFallback>
              </Avatar>
              <div className="text-sm">
                <div className="font-medium text-foreground">{displayName}</div>
                {isAdmin && <div className="text-xs text-muted-foreground">Админ</div>}
              </div>
              <ChevronDown className="w-4 h-4 text-muted-foreground" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem 
                onClick={() => navigate("/profile")} 
                className="cursor-pointer"
              >
                <Settings className="w-4 h-4 mr-2" />
                Настройки профиля
              </DropdownMenuItem>
              {isAdmin && (
                <DropdownMenuItem 
                  onClick={() => navigate("/admin/panel")} 
                  className="cursor-pointer"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Админ панель
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={handleLogout} className="cursor-pointer">
                <LogOut className="w-4 h-4 mr-2" />
                Выход
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
});

Header.displayName = 'Header';

export default Header;
