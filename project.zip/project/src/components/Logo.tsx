import logo from "@/assets/logo.png";

const Logo = ({ className = "h-8" }: { className?: string }) => {
  return (
    <img 
      src={logo} 
      alt="ПЭК" 
      className={className}
    />
  );
};

export default Logo;
